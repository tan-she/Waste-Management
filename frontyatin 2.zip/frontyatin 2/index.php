<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clearearth";
$contactTable = "contact_form_submissions";
$newsletterTable = "newsletter_subscribers";

$contactFormMessage = '';
$contactFormStatus = '';
$newsletterMessage = '';
$newsletterStatus = '';

// ChatGPT API Configuration
$OPENAI_API_KEY = 'YOUR_API_KEY'; // Replace with your actual API key
$OPENAI_API_URL = 'https://api.openai.com/v1/chat/completions';

// Function to call ChatGPT API
function callChatGPT($prompt) {
    global $OPENAI_API_KEY, $OPENAI_API_URL;
    
    $headers = [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $OPENAI_API_KEY
    ];
    
    $data = [
        'model' => 'gpt-3.5-turbo',
        'messages' => [
            [
                'role' => 'system',
                'content' => 'You are a helpful waste management assistant. Provide concise, accurate advice about waste disposal and recycling.'
            ],
            [
                'role' => 'user',
                'content' => $prompt
            ]
        ],
        'temperature' => 0.7,
        'max_tokens' => 150
    ];
    
    $ch = curl_init($OPENAI_API_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode === 200) {
        $result = json_decode($response, true);
        return $result['choices'][0]['message']['content'] ?? 'Sorry, I could not process your request.';
    } else {
        error_log("ChatGPT API Error: " . $response);
        return 'Sorry, there was an error processing your request.';
    }
}

// Handle AI chat form submission
$aiResponse = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ai_question'])) {
    $question = trim($_POST['ai_question']);
    if (!empty($question)) {
        $aiResponse = callChatGPT($question);
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_contact'])) {
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING);

    if (empty($name) || empty($email) || empty($message)) {
        $contactFormMessage = 'Please fill in all contact form fields.';
        $contactFormStatus = 'error';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $contactFormMessage = 'Invalid email format in contact form.';
        $contactFormStatus = 'error';
    } else {
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            error_log("Contact DB Connection Error: " . $conn->connect_error);
            $contactFormMessage = 'Service connection error. Please try again later.';
            $contactFormStatus = 'error';
        } else {
            $stmt = $conn->prepare("INSERT INTO $contactTable (name, email, message) VALUES (?, ?, ?)");
            if ($stmt === false) {
                error_log("Contact Prepare Error: (" . $conn->errno . ") " . $conn->error);
                $contactFormMessage = 'Database error (prepare). Please try again later.';
                $contactFormStatus = 'error';
            } else {
                $stmt->bind_param("sss", $name, $email, $message);
                if ($stmt->execute()) {
                    $contactFormMessage = 'Thank you for contacting us! We have received your message and will get back to you shortly.';
                    $contactFormStatus = 'success';
                    $_POST = array();
                } else {
                    error_log("Contact Execute Error: (" . $stmt->errno . ") " . $stmt->error);
                    $contactFormMessage = 'Failed to send message due to a server issue. Please try again later.';
                    $contactFormStatus = 'error';
                }
                $stmt->close();
            }
            $conn->close();
        }
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_newsletter'])) {
    $newsletterEmailInput = filter_input(INPUT_POST, 'newsletter_email', FILTER_SANITIZE_EMAIL);

    if (empty($newsletterEmailInput)) {
        $newsletterMessage = 'Please enter an email address.';
        $newsletterStatus = 'error';
    } elseif (!filter_var($newsletterEmailInput, FILTER_VALIDATE_EMAIL)) {
        $newsletterMessage = 'Invalid email format entered.';
        $newsletterStatus = 'error';
    } else {
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            error_log("Newsletter DB Connection Error: " . $conn->connect_error);
            $newsletterMessage = 'Could not connect to the subscription service. Please try again later.';
            $newsletterStatus = 'error';
        } else {
            $stmt = $conn->prepare("INSERT IGNORE INTO $newsletterTable (email) VALUES (?)");
            if ($stmt === false) {
                 error_log("Newsletter Prepare Error: (" . $conn->errno . ") " . $conn->error);
                 $newsletterMessage = 'Database error during subscription (prepare).';
                 $newsletterStatus = 'error';
            } else {
                $stmt->bind_param("s", $newsletterEmailInput);
                if ($stmt->execute()) {
                    if ($stmt->affected_rows > 0) {
                        $newsletterMessage = 'Thank you for subscribing!';
                        $newsletterStatus = 'success';
                    } else {
                        $checkStmt = $conn->prepare("SELECT id FROM $newsletterTable WHERE email = ?");
                        if ($checkStmt) {
                             $checkStmt->bind_param("s", $newsletterEmailInput);
                             $checkStmt->execute();
                             $checkStmt->store_result();
                             if ($checkStmt->num_rows > 0) {
                                 $newsletterMessage = 'This email is already subscribed!';
                                 $newsletterStatus = 'info';
                             } else {
                                 $newsletterMessage = 'Subscription could not be processed (Code: IGNORE_0_NF).';
                                 $newsletterStatus = 'error';
                             }
                             $checkStmt->close();
                        } else {
                             $newsletterMessage = 'Could not verify subscription status.';
                             $newsletterStatus = 'error';
                        }
                    }
                } else {
                    error_log("Newsletter Execute Error: (" . $stmt->errno . ") " . $stmt->error);
                    $newsletterMessage = 'Subscription failed due to a server issue.';
                    $newsletterStatus = 'error';
                }
                $stmt->close();
            }
            $conn->close();
        }
    }
      unset($_POST['submit_newsletter']);
      unset($_POST['newsletter_email']);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clear Earth Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="styles.css">
    <style>
        body { font-family: 'Poppins', sans-serif; }
        .logo-container { width: 48px; height: 48px; position: relative; display: flex; align-items: center; justify-content: center; }
        .logo-circle { width: 100%; height: 100%; border-radius: 50%; background: linear-gradient(135deg, #4f46e5 0%, #ec4899 100%); display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06); transition: transform 0.3s ease, box-shadow 0.3s ease; }
        .logo-circle:hover { transform: scale(1.05); box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05); }
        .recycle-arrows { width: 24px; height: 24px; animation: spin 20s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }

        .hero-section {
            position: relative;
            height: 70vh;
            min-height: 450px;
            color: white;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .slideshow-container {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
        }
        .slide {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-size: cover;
            background-position: center;
            opacity: 0;
            transition: opacity 1.5s ease-in-out;
            filter: brightness(0.6); /* This darkens the background images */
        }
        .slide.active { opacity: 1; z-index: 3; }
        .slide.prev { z-index: 2; }
        .hero-content {
            position: relative;
            z-index: 10;
            background-color: rgba(0, 0, 0, 0.4);
            padding: 2rem 3rem;
            border-radius: 1rem;
            max-width: 800px;
        }
        .hero-title { font-weight: 900; }
        @keyframes word-bounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }
        .animate-word-bounce { animation: word-bounce 1.5s ease-in-out infinite; }
        .animate-word-bounce-delay-1 { animation: word-bounce 1.5s ease-in-out 0.2s infinite; }
        .animate-word-bounce-delay-2 { animation: word-bounce 1.5s ease-in-out 0.4s infinite; }
        @keyframes spin-slow { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        .animate-spin-slow { animation: spin-slow 10s linear infinite; }
        @keyframes fade-in-up { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        .animate-fade-in-up { animation: fade-in-up 1s ease-out forwards; }

        .typewriter { overflow: hidden; white-space: nowrap; border-right: .1em solid #6366F1; animation: typing 3s steps(60, end) forwards, blink-caret .75s step-end infinite; width: 0; }
        .typewriter-line { display: block; opacity: 0; animation: fade-in 0.5s ease forwards; }
        @keyframes typing { from { width: 0 } to { width: 100% } }
        @keyframes blink-caret { from, to { border-color: transparent } 50% { border-color: #6366F1; } }
        @keyframes fade-in { from { opacity: 0; } to { opacity: 1; } }
        .typewriter-line:nth-child(1) { animation-delay: 0.5s; }
        .typewriter-line:nth-child(2) { animation-delay: 1.5s; }
        .typewriter-line:nth-child(3) { animation-delay: 2.5s; }
        .typewriter-line:nth-child(4) { animation-delay: 3.5s; }
        .typewriter-line:nth-child(5) { animation-delay: 4.5s; }
        .typewriter-line:nth-child(6) { animation-delay: 5.5s; }

        .consequences-container .section-box .title-box { transition: background-color 0.3s ease; }
        .consequences-container .section-box:hover .title-box { filter: brightness(0.95); }
        .consequences-container .content-list { max-height: 0; overflow: hidden; transition: max-height 0.5s ease-out, padding 0.5s ease-out, opacity 0.3s ease-out, margin-top 0.5s ease-out; opacity: 0; padding-top: 0; padding-bottom: 0; margin-top: 0; }
        .consequences-container .content-list.show { max-height: 300px; opacity: 1; padding-top: 1rem; padding-bottom: 1rem; margin-top: 0.5rem; }

        .flow-container::before, .flow-container::after { content: ""; position: absolute; top: 50px; height: 2px; background-color: #cbd5e1; z-index: 0; }
        .flow-container::before { left: 7%; width: 86%; transform: translateY(-50%); }

        #newsPopup { transition: opacity 0.3s ease-out; }
        #newsPopupContent { transition: transform 0.3s ease-out, opacity 0.3s ease-out; }
        .prose ul { list-style-type: disc; padding-left: 1.5rem; }
        .prose p { margin-bottom: 1rem; }

        .contact-success-message { text-align: center; padding: 3rem 1.5rem; border: 2px dashed #4CAF50; border-radius: 0.75rem; background-color: #f0fff4; }
        .contact-success-message .icon { font-size: 3.5rem; margin-bottom: 1rem; color: #4CAF50; animation: bounce 1s infinite; }
        .contact-success-message h3 { font-size: 1.75rem; font-weight: 700; color: #2F855A; margin-bottom: 0.75rem; }
        .contact-success-message p { font-size: 1rem; color: #38A169; line-height: 1.6; }
        .contact-error-message { background-color: #fef2f2; color: #dc2626; border: 1px solid #fecaca; padding: 1rem; margin-bottom: 1.5rem; border-radius: 0.5rem; text-align: center; font-weight: 500; }
        @keyframes bounce { 0%, 100% { transform: translateY(-5%); animation-timing-function: cubic-bezier(0.8, 0, 1, 1); } 50% { transform: translateY(0); animation-timing-function: cubic-bezier(0, 0, 0.2, 1); } }

         .newsletter-msg {
             font-size: 0.875rem;
             margin-top: 0.5rem;
             font-weight: 600;
             transition: opacity 0.3s ease-in-out;
             height: 1.25rem;
             line-height: 1.25rem;
        }
        .newsletter-msg.success { color: #16a34a; }
        .newsletter-msg.error { color: #dc2626; }
        .newsletter-msg.info { color: #2563eb; }

        .ai-chat-section {
            padding: 4rem 0;
            background-color: #f8f9fa;
        }
        
        .ai-chat-container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .ai-chat-form .form-group {
            display: flex;
            gap: 1rem;
            margin-bottom: 1rem;
        }
        
        .ai-chat-form input {
            flex: 1;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }
        
        .ai-response {
            margin-top: 2rem;
            padding: 1rem;
            background: #f0f7ff;
            border-radius: 5px;
            border-left: 4px solid #007bff;
        }
        
        .ai-response h3 {
            color: #007bff;
            margin-bottom: 0.5rem;
        }
    </style>
</head>

<body class="bg-gradient-to-b from-indigo-50 to-purple-50">
       <nav class="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white sticky top-0 z-50 shadow-lg" style="height: 64px;">
        <div class="container mx-auto h-full flex items-center justify-center relative px-4">
            <div class="absolute left-4">
                <a href="index.php">
                    <div class="logo-container">
                        <div class="logo-circle">
                            <svg class="recycle-arrows" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 24px; height: 24px;">
                                <path d="M21 10C21 7.17157 19.9464 4.45867 18.0711 2.58337C16.1957 0.708074 13.4828 -0.345703 10.6544 -0.345703" stroke="white" stroke-width="2" stroke-linecap="round" transform="rotate(0 12 12)"><animateTransform attributeName="transform" type="rotate" from="0 12 12" to="120 12 12" dur="3s" repeatCount="indefinite"/></path>
                                <path d="M10.6544 -0.345703L13.6544 2.65429L7.6544 2.65429L10.6544 -0.345703Z" fill="white" transform="rotate(0 12 12)"><animateTransform attributeName="transform" type="rotate" from="0 12 12" to="120 12 12" dur="3s" repeatCount="indefinite"/></path>
                                <path d="M21 10C21 7.17157 19.9464 4.45867 18.0711 2.58337C16.1957 0.708074 13.4828 -0.345703 10.6544 -0.345703" stroke="white" stroke-width="2" stroke-linecap="round" transform="rotate(120 12 12)"><animateTransform attributeName="transform" type="rotate" from="120 12 12" to="240 12 12" dur="3s" repeatCount="indefinite"/></path>
                                <path d="M10.6544 -0.345703L13.6544 2.65429L7.6544 2.65429L10.6544 -0.345703Z" fill="white" transform="rotate(120 12 12)"><animateTransform attributeName="transform" type="rotate" from="120 12 12" to="240 12 12" dur="3s" repeatCount="indefinite"/></path>
                                <path d="M21 10C21 7.17157 19.9464 4.45867 18.0711 2.58337C16.1957 0.708074 13.4828 -0.345703 10.6544 -0.345703" stroke="white" stroke-width="2" stroke-linecap="round" transform="rotate(240 12 12)"><animateTransform attributeName="transform" type="rotate" from="240 12 12" to="360 12 12" dur="3s" repeatCount="indefinite"/></path>
                                <path d="M10.6544 -0.345703L13.6544 2.65429L7.6544 2.65429L10.6544 -0.345703Z" fill="white" transform="rotate(240 12 12)"><animateTransform attributeName="transform" type="rotate" from="240 12 12" to="360 12 12" dur="3s" repeatCount="indefinite"/></path>
                            </svg>
                        </div>
                    </div>
                </a>
            </div>
            <div class="hidden md:flex items-center justify-center space-x-6 lg:space-x-8">
                <a href="index.php" class="text-white hover:text-indigo-200 transition-colors duration-300 font-medium">Home</a>
                <a href="learn-segregation.php" class="text-white hover:text-indigo-200 transition-colors duration-300 font-medium">Learn Segregation</a>
                <a href="ai-identifier.php" class="text-white hover:text-indigo-200 transition-colors duration-300 font-medium">AI Identifier</a>
                <a href="disposal-centers.php" class="text-white hover:text-indigo-200 transition-colors duration-300 font-medium">Find Disposal Centers</a>
                <a href="contact.php" class="text-white hover:text-indigo-200 transition-colors duration-300 font-medium">Contact Us</a>
                 <?php if (isset($_SESSION['name'])): ?>
                    <a href="logout.php" class="bg-red-600 text-white px-3 py-1.5 rounded-md text-sm hover:bg-red-700 transition duration-300">Logout</a>
                <?php else: ?>
                    <a href="login.php" class="bg-green-600 text-white px-3 py-1.5 rounded-md text-sm hover:bg-green-700 transition duration-300">Login</a>
                <?php endif; ?>
            </div>
             <div class="md:hidden absolute right-4">
                <button id="mobile-menu-button" class="text-white focus:outline-none">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path></svg>
                </button>
             </div>
        </div>
         <div id="mobile-menu" class="md:hidden hidden bg-indigo-700 p-4 space-y-2">
            <a href="index.php" class="block text-white hover:text-indigo-200 transition-colors duration-300">Home</a>
            <a href="learn-segregation.php" class="block text-white hover:text-indigo-200 transition-colors duration-300">Learn Segregation</a>
            <a href="ai-identifier.php" class="block text-white hover:text-indigo-200 transition-colors duration-300">AI Identifier</a>
            <a href="disposal-centers.php" class="block text-white hover:text-indigo-200 transition-colors duration-300">Find Disposal Centers</a>
            <a href="contact.php" class="block text-white hover:text-indigo-200 transition-colors duration-300">Contact Us</a>
            <?php if (isset($_SESSION['name'])): ?>
                <a href="logout.php" class="block bg-red-600 text-center text-white px-3 py-1.5 rounded-md text-sm hover:bg-red-700 transition duration-300">Logout</a>
            <?php else: ?>
                <a href="login.php" class="block bg-green-600 text-center text-white px-3 py-1.5 rounded-md text-sm hover:bg-green-700 transition duration-300">Login</a>
            <?php endif; ?>
        </div>
    </nav>

    <main class="container mx-auto px-4 pt-16 pb-16">

        <section class="hero-section flex items-center justify-center mb-16" style="padding-top: 0;">
            <div class="slideshow-container">
                 <div class="slide active" style="background-image: url('https://images.unsplash.com/photo-1532187643603-ba119ca4109e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80');"></div>
                <div class="slide" style="background-image: url('https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80');"></div>
                <div class="slide" style="background-image: url('https://images.unsplash.com/photo-1595278069441-2cf29f8005a4?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80');"></div>
                <div class="slide" style="background-image: url('https://images.unsplash.com/photo-1604187351574-c75ca79f5807?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80');"></div>
                <div class="slide" style="background-image: url('https://images.unsplash.com/photo-1528323273322-d81458248d40?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80');"></div>
                <div class="slide" style="background-image: url('https://images.unsplash.com/photo-1605600659908-0ef719419d41?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80');"></div>
                <div class="slide" style="background-image: url('https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80');"></div>
            </div>
            <div class="hero-content text-center animate-fade-in-up hover:shadow-2xl transition-shadow duration-300">
                <h1 class="hero-title text-5xl sm:text-6xl lg:text-7xl mb-4 sm:mb-6 relative group">
                    <span class="inline-block text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 animate-word-bounce drop-shadow-lg">Clear</span>
                    <span class="inline-block text-transparent bg-clip-text bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 animate-word-bounce-delay-1 drop-shadow-lg">Earth</span>
                    <span class="inline-block text-transparent bg-clip-text bg-gradient-to-r from-pink-600 via-indigo-600 to-purple-600 animate-word-bounce-delay-2 drop-shadow-lg">Dashboard</span>
                    <span class="inline-block ml-1 sm:ml-2 animate-bounce text-4xl sm:text-6xl">🌍</span>
                    <span class="inline-block ml-1 sm:ml-2 animate-spin-slow text-4xl sm:text-6xl">♻️</span>
                </h1>
                <p class="text-lg sm:text-xl font-semibold mb-8 sm:mb-12 max-w-xl sm:max-w-2xl mx-auto tracking-wide text-white/90">Your Smart Solution for Waste Management and Environmental Sustainability</p>
            </div>
        </section>

         <div class="px-4 mt-8 mb-16">
            <div class="max-w-4xl mx-auto">
                <div class="bg-gradient-to-r from-indigo-100 via-purple-100 to-pink-100 p-6 sm:p-8 rounded-xl shadow-lg transform hover:scale-[1.03] transition-all duration-300 hover:shadow-2xl">
                    <p class="text-2xl sm:text-3xl font-bold text-center text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600">
                        🌱 A Clear Earth Starts With You 🌍
                    </p>
                    <div class="flex justify-center mt-4 space-x-4">
                        <span class="text-3xl sm:text-4xl animate-bounce">♻️</span>
                        <span class="text-3xl sm:text-4xl animate-spin-slow">🌿</span>
                        <span class="text-3xl sm:text-4xl animate-bounce" style="animation-delay: 0.2s">🌳</span>
                    </div>
                </div>
            </div>
         </div>

        <div class="px-4 mb-16">
           <div class="mx-auto">
                <div class="bg-white p-6 sm:p-8 rounded-xl shadow-lg transform hover:scale-[1.03] transition-all duration-300 hover:shadow-2xl">
                    <div class="text-center">
                        <h2 class="text-2xl sm:text-3xl font-bold mb-6 sm:mb-8 text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 typewriter relative inline-block">
                            Why Waste Management?
                            <div class="absolute bottom-0 left-0 w-full h-0.5 sm:h-1 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600"></div>
                        </h2>
                    </div>
                    <div class="text-base sm:text-lg text-gray-700 leading-relaxed space-y-3 sm:space-y-4">
                        <span class="typewriter-line flex items-start"><span class="text-xl sm:text-2xl mr-2 text-indigo-600 flex-shrink-0 pt-1">🌱</span><span class="text-indigo-600">Waste management is crucial for preserving our planet's health and ensuring a sustainable future.</span></span>
                        <span class="typewriter-line flex items-start"><span class="text-xl sm:text-2xl mr-2 text-purple-600 flex-shrink-0 pt-1">♻️</span><span class="text-purple-600">Millions of tons of waste end up in landfills and oceans yearly, causing severe environmental damage.</span></span>
                        <span class="typewriter-line flex items-start"><span class="text-xl sm:text-2xl mr-2 text-pink-600 flex-shrink-0 pt-1">🌍</span><span class="text-pink-600">Proper waste management reduces pollution, conserves resources, and minimizes greenhouse gas emissions.</span></span>
                        <span class="typewriter-line flex items-start"><span class="text-xl sm:text-2xl mr-2 text-green-600 flex-shrink-0 pt-1">🌿</span><span class="text-green-600">Responsible disposal protects ecosystems, improves public health, and creates a cleaner world.</span></span>
                        <span class="typewriter-line flex items-start"><span class="text-xl sm:text-2xl mr-2 text-blue-600 flex-shrink-0 pt-1">💧</span><span class="text-blue-600">Remember, every small action counts - from recycling one bottle to segregating waste at home.</span></span>
                        <span class="typewriter-line flex items-start"><span class="text-xl sm:text-2xl mr-2 text-amber-600 flex-shrink-0 pt-1">🌟</span><span class="text-amber-600">Together, we can make a significant impact on our planet's well-being.</span></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="px-4 mb-16">
            <div class="mx-auto">
                <div class="bg-white p-6 sm:p-8 rounded-xl shadow-lg transform hover:scale-[1.03] transition-all duration-300 hover:shadow-2xl">
                    <div class="text-center">
                        <h2 class="text-2xl sm:text-3xl font-bold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 typewriter relative inline-block">
                            Consequences of Poor Waste Management
                            <div class="absolute bottom-0 left-0 w-full h-0.5 sm:h-1 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600"></div>
                        </h2>
                    </div>
                    <div class="consequences-container">
                        <div class="consequences-content">
                            <div class="diagram-container relative">
                                <div class="main-title bg-gradient-to-r from-sky-400 to-pink-400 text-white rounded-lg p-3 sm:p-4 mb-6 sm:mb-8 w-fit mx-auto shadow-md">
                                    <h2 class="text-xl sm:text-2xl font-bold text-center">Consequences</h2>
                                </div>
                                <div class="content-boxes grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 sm:gap-6 mt-8">
                                    <div class="section-box cursor-pointer" onclick="toggleDetails(this)">
                                        <div class="title-box bg-emerald-100 p-2 sm:p-3 rounded-lg border-2 border-emerald-500 hover:bg-emerald-200 transition-colors flex flex-col items-center justify-center min-h-[80px] sm:min-h-[100px]">
                                            <span class="text-xl sm:text-2xl mb-1">🌍</span>
                                            <h3 class="text-emerald-700 font-semibold text-xs sm:text-sm text-center leading-tight">Environmental<br>Pollution</h3>
                                        </div>
                                        <div class="content-list bg-white rounded-lg border-2 border-emerald-500 p-3 sm:p-4 mt-2 hidden">
                                            <img src="https://images.unsplash.com/photo-1611284446314-60a58ac0deb9" alt="Environmental Pollution" class="w-full h-16 sm:h-24 object-cover rounded-lg mb-2 sm:mb-3">
                                            <ul class="space-y-1 sm:space-y-2 text-xs sm:text-sm">
                                                <li class="flex items-center text-emerald-600"><span class="mr-1.5">•</span>Air Pollution</li>
                                                <li class="flex items-center text-emerald-600"><span class="mr-1.5">•</span>Water Pollution</li>
                                                <li class="flex items-center text-emerald-600"><span class="mr-1.5">•</span>Soil Damage</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="section-box cursor-pointer" onclick="toggleDetails(this)">
                                        <div class="title-box bg-red-100 p-2 sm:p-3 rounded-lg border-2 border-red-500 hover:bg-red-200 transition-colors flex flex-col items-center justify-center min-h-[80px] sm:min-h-[100px]">
                                            <span class="text-xl sm:text-2xl mb-1">🌡️</span>
                                            <h3 class="text-red-700 font-semibold text-xs sm:text-sm text-center leading-tight">Global<br>Warming</h3>
                                        </div>
                                        <div class="content-list bg-white rounded-lg border-2 border-red-500 p-3 sm:p-4 mt-2 hidden">
                                             <img src="https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05" alt="Global Warming" class="w-full h-16 sm:h-24 object-cover rounded-lg mb-2 sm:mb-3">
                                            <ul class="space-y-1 sm:space-y-2 text-xs sm:text-sm">
                                                <li class="flex items-center text-red-600"><span class="mr-1.5">•</span>Greenhouse Gases</li>
                                                <li class="flex items-center text-red-600"><span class="mr-1.5">•</span>Ice Melting</li>
                                                <li class="flex items-center text-red-600"><span class="mr-1.5">•</span>Temperature Rise</li>
                                            </ul>
                                        </div>
                                    </div>
                                     <div class="section-box cursor-pointer" onclick="toggleDetails(this)">
                                        <div class="title-box bg-blue-100 p-2 sm:p-3 rounded-lg border-2 border-blue-500 hover:bg-blue-200 transition-colors flex flex-col items-center justify-center min-h-[80px] sm:min-h-[100px]">
                                            <span class="text-xl sm:text-2xl mb-1">🏥</span>
                                            <h3 class="text-blue-700 font-semibold text-xs sm:text-sm text-center leading-tight">Health<br>Issues</h3>
                                        </div>
                                        <div class="content-list bg-white rounded-lg border-2 border-blue-500 p-3 sm:p-4 mt-2 hidden">
                                             <img src="https://images.unsplash.com/photo-1583324113626-70df0f4deaab" alt="Health Issues" class="w-full h-16 sm:h-24 object-cover rounded-lg mb-2 sm:mb-3">
                                            <ul class="space-y-1 sm:space-y-2 text-xs sm:text-sm">
                                                <li class="flex items-center text-blue-600"><span class="mr-1.5">•</span>Diseases</li>
                                                <li class="flex items-center text-blue-600"><span class="mr-1.5">•</span>Respiratory Issues</li>
                                                <li class="flex items-center text-blue-600"><span class="mr-1.5">•</span>Mental Health</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="section-box cursor-pointer" onclick="toggleDetails(this)">
                                        <div class="title-box bg-cyan-100 p-2 sm:p-3 rounded-lg border-2 border-cyan-500 hover:bg-cyan-200 transition-colors flex flex-col items-center justify-center min-h-[80px] sm:min-h-[100px]">
                                            <span class="text-xl sm:text-2xl mb-1">🐋</span>
                                            <h3 class="text-cyan-700 font-semibold text-xs sm:text-sm text-center leading-tight">Marine<br>Life</h3>
                                        </div>
                                        <div class="content-list bg-white rounded-lg border-2 border-cyan-500 p-3 sm:p-4 mt-2 hidden">
                                            <img src="https://images.unsplash.com/photo-1583212292454-1fe6229603b7" alt="Marine Life" class="w-full h-16 sm:h-24 object-cover rounded-lg mb-2 sm:mb-3">
                                            <ul class="space-y-1 sm:space-y-2 text-xs sm:text-sm">
                                                <li class="flex items-center text-cyan-600"><span class="mr-1.5">•</span>Ocean Pollution</li>
                                                <li class="flex items-center text-cyan-600"><span class="mr-1.5">•</span>Species Loss</li>
                                                <li class="flex items-center text-cyan-600"><span class="mr-1.5">•</span>Habitat Damage</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="section-box cursor-pointer" onclick="toggleDetails(this)">
                                        <div class="title-box bg-amber-100 p-2 sm:p-3 rounded-lg border-2 border-amber-500 hover:bg-amber-200 transition-colors flex flex-col items-center justify-center min-h-[80px] sm:min-h-[100px]">
                                            <span class="text-xl sm:text-2xl mb-1">💰</span>
                                            <h3 class="text-amber-700 font-semibold text-xs sm:text-sm text-center leading-tight">Economic<br>Impact</h3>
                                        </div>
                                        <div class="content-list bg-white rounded-lg border-2 border-amber-500 p-3 sm:p-4 mt-2 hidden">
                                             <img src="https://images.unsplash.com/photo-1518458028785-8fbcd101ebb9" alt="Economic Impact" class="w-full h-16 sm:h-24 object-cover rounded-lg mb-2 sm:mb-3">
                                            <ul class="space-y-1 sm:space-y-2 text-xs sm:text-sm">
                                                <li class="flex items-center text-amber-600"><span class="mr-1.5">•</span>Resource Loss</li>
                                                <li class="flex items-center text-amber-600"><span class="mr-1.5">•</span>Tourism Impact</li>
                                                <li class="flex items-center text-amber-600"><span class="mr-1.5">•</span>Healthcare Costs</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="px-4 mb-16">
            <div class="mx-auto">
                 <div class="bg-white p-6 sm:p-8 rounded-xl shadow-lg transform hover:scale-[1.03] transition-all duration-300 hover:shadow-2xl">
                    <div class="text-center mb-8 sm:mb-12">
                        <h2 class="text-2xl sm:text-3xl font-bold mb-3 sm:mb-4 text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600">
                            Solutions for Better Waste Management
                            <div class="absolute bottom-0 left-0 w-full h-0.5 sm:h-1 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600"></div>
                        </h2>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
                        <div class="solution-card bg-gradient-to-br from-emerald-50 to-teal-50 p-5 sm:p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col">
                            <div class="text-center mb-4 flex-grow">
                                <span class="text-4xl sm:text-5xl mb-3 sm:mb-4 block">🗑️</span>
                                <h3 class="text-xl sm:text-2xl font-bold text-emerald-700 mb-2 sm:mb-3">Waste Segregation</h3>
                                <p class="text-sm sm:text-base text-gray-600 mb-4 sm:mb-6 leading-relaxed">
                                    Learn to separate dry & wet waste, identify recyclables, and dispose of hazardous items correctly.
                                </p>
                            </div>
                             <a href="learn-segregation.php" class="mt-auto inline-flex items-center justify-center px-5 py-2.5 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors duration-300 text-sm sm:text-base font-medium">
                                <span class="mr-2">📚</span> Learn More
                            </a>
                        </div>
                        <div class="solution-card bg-gradient-to-br from-amber-50 to-orange-50 p-5 sm:p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col">
                            <div class="text-center mb-4 flex-grow">
                                <span class="text-4xl sm:text-5xl mb-3 sm:mb-4 block">🌱</span>
                                <h3 class="text-xl sm:text-2xl font-bold text-amber-700 mb-2 sm:mb-3">Composting at Home</h3>
                                <p class="text-sm sm:text-base text-gray-600 mb-4 sm:mb-6 leading-relaxed">
                                    Turn kitchen scraps into nutrient-rich compost for your garden. Easy setup and maintenance tips.
                                </p>
                            </div>
                            <a href="https://www.youtube.com/watch?v=Q5s4n9r-JGU" target="_blank" rel="noopener noreferrer" class="mt-auto inline-flex items-center justify-center px-5 py-2.5 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors duration-300 text-sm sm:text-base font-medium">
                                <span class="mr-2">▶️</span> Watch Video
                            </a>
                        </div>
                        <div class="solution-card bg-gradient-to-br from-blue-50 to-indigo-50 p-5 sm:p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col">
                             <div class="text-center mb-4 flex-grow">
                                <span class="text-4xl sm:text-5xl mb-3 sm:mb-4 block">♻️</span>
                                <h3 class="text-xl sm:text-2xl font-bold text-blue-700 mb-2 sm:mb-3">Smart Recycling</h3>
                                <p class="text-sm sm:text-base text-gray-600 mb-4 sm:mb-6 leading-relaxed">
                                    Discover innovative ways to recycle, reuse, and upcycle common household items effectively.
                                </p>
                            </div>
                            <a href="https://www.youtube.com/watch?v=OasbYWF4_S8" target="_blank" rel="noopener noreferrer" class="mt-auto inline-flex items-center justify-center px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-300 text-sm sm:text-base font-medium">
                                <span class="mr-2">▶️</span> Watch Video
                            </a>
                        </div>
                         <div class="solution-card bg-gradient-to-br from-purple-50 to-pink-50 p-5 sm:p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col">
                            <div class="text-center mb-4 flex-grow">
                                <span class="text-4xl sm:text-5xl mb-3 sm:mb-4 block">🌍</span>
                                <h3 class="text-xl sm:text-2xl font-bold text-purple-700 mb-2 sm:mb-3">Zero Waste Lifestyle</h3>
                                <p class="text-sm sm:text-base text-gray-600 mb-4 sm:mb-6 leading-relaxed">
                                    Adopt practices like using reusable containers, buying in bulk, and sustainable shopping to reduce waste.
                                </p>
                            </div>
                            <a href="https://www.youtube.com/watch?v=6jQ7y_qQYUA" target="_blank" rel="noopener noreferrer" class="mt-auto inline-flex items-center justify-center px-5 py-2.5 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors duration-300 text-sm sm:text-base font-medium">
                                <span class="mr-2">▶️</span> Watch Video
                            </a>
                        </div>
                        <div class="solution-card bg-gradient-to-br from-rose-50 to-pink-50 p-5 sm:p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col">
                             <div class="text-center mb-4 flex-grow">
                                <span class="text-4xl sm:text-5xl mb-3 sm:mb-4 block">🛍️</span>
                                <h3 class="text-xl sm:text-2xl font-bold text-rose-700 mb-2 sm:mb-3">Eco-friendly Products</h3>
                                <p class="text-sm sm:text-base text-gray-600 mb-4 sm:mb-6 leading-relaxed">
                                    Choose sustainable alternatives like biodegradable items, energy-efficient appliances, and green cleaners.
                                </p>
                            </div>
                             <a href="https://www.youtube.com/watch?v=Q5s4n9r-JGU" target="_blank" rel="noopener noreferrer" class="mt-auto inline-flex items-center justify-center px-5 py-2.5 bg-rose-600 text-white rounded-lg hover:bg-rose-700 transition-colors duration-300 text-sm sm:text-base font-medium">
                                <span class="mr-2">▶️</span> Watch Video
                            </a>
                        </div>
                        <div class="solution-card bg-gradient-to-br from-cyan-50 to-teal-50 p-5 sm:p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col">
                            <div class="text-center mb-4 flex-grow">
                                <span class="text-4xl sm:text-5xl mb-3 sm:mb-4 block">👥</span>
                                <h3 class="text-xl sm:text-2xl font-bold text-cyan-700 mb-2 sm:mb-3">Community Initiatives</h3>
                                <p class="text-sm sm:text-base text-gray-600 mb-4 sm:mb-6 leading-relaxed">
                                    Participate in local clean-up drives, recycling programs, and educational workshops to make a collective impact.
                                </p>
                            </div>
                            <a href="https://www.youtube.com/watch?v=OasbYWF4_S8" target="_blank" rel="noopener noreferrer" class="mt-auto inline-flex items-center justify-center px-5 py-2.5 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 transition-colors duration-300 text-sm sm:text-base font-medium">
                                <span class="mr-2">▶️</span> Watch Video
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="px-4 mb-16">
           <div class="mx-auto">
                 <div class="waste-management-flow bg-white p-6 sm:p-8 rounded-xl shadow-lg overflow-x-auto">
                    <h2 class="text-2xl sm:text-3xl font-bold mb-8 sm:mb-12 text-center text-transparent bg-clip-text bg-gradient-to-r from-green-600 to-teal-600">
                        Waste Management Process
                    </h2>
                    <div class="flow-container relative min-w-[700px] sm:min-w-[800px]">
                         <div class="absolute top-[45px] sm:top-[50px] left-0 right-0 h-0.5 sm:h-1 bg-gray-300 -z-10" style="transform: translateY(-50%);"></div>

                        <div class="grid grid-cols-7 gap-2 sm:gap-4 items-start">
                            <div class="process-step text-center relative px-1">
                                <div class="icon-box bg-gradient-to-br from-gray-50 to-gray-100 p-3 sm:p-4 rounded-full shadow-md mb-2 sm:mb-3 inline-block z-10 border-2 border-gray-300">
                                    <span class="text-2xl sm:text-4xl">🏠</span>
                                </div>
                                 <div class="absolute top-[45px] sm:top-[50px] left-1/2 w-2 h-2 sm:w-3 sm:h-3 bg-gray-500 rounded-full -translate-x-1/2 -translate-y-1/2 z-0"></div>
                                <h3 class="font-semibold text-gray-800 mt-1 sm:mt-2 text-[10px] sm:text-sm md:text-base leading-tight">SOURCE</h3>
                                <p class="text-[9px] sm:text-xs md:text-sm text-gray-600 leading-tight">Household & Industrial</p>
                            </div>
                            <div class="process-step text-center relative px-1">
                                <div class="icon-box bg-gradient-to-br from-green-50 to-emerald-100 p-3 sm:p-4 rounded-full shadow-md mb-2 sm:mb-3 inline-block z-10 border-2 border-emerald-300">
                                    <span class="text-2xl sm:text-4xl">♻️</span>
                                </div>
                                 <div class="absolute top-[45px] sm:top-[50px] left-1/2 w-2 h-2 sm:w-3 sm:h-3 bg-emerald-500 rounded-full -translate-x-1/2 -translate-y-1/2 z-0"></div>
                                <h3 class="font-semibold text-gray-800 mt-1 sm:mt-2 text-[10px] sm:text-sm md:text-base leading-tight">PRIMARY SORTING</h3>
                                <p class="text-[9px] sm:text-xs md:text-sm text-gray-600 leading-tight">Segregation at Source</p>
                            </div>
                             <div class="process-step text-center relative px-1">
                                <div class="icon-box bg-gradient-to-br from-blue-50 to-sky-100 p-3 sm:p-4 rounded-full shadow-md mb-2 sm:mb-3 inline-block z-10 border-2 border-sky-300">
                                    <span class="text-2xl sm:text-4xl">🚛</span>
                                </div>
                                 <div class="absolute top-[45px] sm:top-[50px] left-1/2 w-2 h-2 sm:w-3 sm:h-3 bg-sky-500 rounded-full -translate-x-1/2 -translate-y-1/2 z-0"></div>
                                <h3 class="font-semibold text-gray-800 mt-1 sm:mt-2 text-[10px] sm:text-sm md:text-base leading-tight">COLLECTION</h3>
                                <p class="text-[9px] sm:text-xs md:text-sm text-gray-600 leading-tight">Transportation</p>
                            </div>
                             <div class="process-step text-center relative px-1">
                                <div class="icon-box bg-gradient-to-br from-purple-50 to-violet-100 p-3 sm:p-4 rounded-full shadow-md mb-2 sm:mb-3 inline-block z-10 border-2 border-violet-300">
                                    <span class="text-2xl sm:text-4xl">🏭</span>
                                </div>
                                 <div class="absolute top-[45px] sm:top-[50px] left-1/2 w-2 h-2 sm:w-3 sm:h-3 bg-violet-500 rounded-full -translate-x-1/2 -translate-y-1/2 z-0"></div>
                                <h3 class="font-semibold text-gray-800 mt-1 sm:mt-2 text-[10px] sm:text-sm md:text-base leading-tight">SECONDARY SORTING</h3>
                                <p class="text-[9px] sm:text-xs md:text-sm text-gray-600 leading-tight">Recovery Facility</p>
                            </div>
                             <div class="process-step text-center relative px-1">
                                <div class="icon-box bg-gradient-to-br from-yellow-50 to-amber-100 p-3 sm:p-4 rounded-full shadow-md mb-2 sm:mb-3 inline-block z-10 border-2 border-amber-300">
                                    <span class="text-2xl sm:text-4xl">🌱</span>
                                </div>
                                <div class="absolute top-[45px] sm:top-[50px] left-1/2 w-2 h-2 sm:w-3 sm:h-3 bg-amber-500 rounded-full -translate-x-1/2 -translate-y-1/2 z-0"></div>
                                <h3 class="font-semibold text-gray-800 mt-1 sm:mt-2 text-[10px] sm:text-sm md:text-base leading-tight">COMPOSTING</h3>
                                <p class="text-[9px] sm:text-xs md:text-sm text-gray-600 leading-tight">Organic Processing</p>
                            </div>
                             <div class="process-step text-center relative px-1">
                                <div class="icon-box bg-gradient-to-br from-cyan-50 to-teal-100 p-3 sm:p-4 rounded-full shadow-md mb-2 sm:mb-3 inline-block z-10 border-2 border-teal-300">
                                    <span class="text-2xl sm:text-4xl">🔄</span>
                                </div>
                                 <div class="absolute top-[45px] sm:top-[50px] left-1/2 w-2 h-2 sm:w-3 sm:h-3 bg-teal-500 rounded-full -translate-x-1/2 -translate-y-1/2 z-0"></div>
                                <h3 class="font-semibold text-gray-800 mt-1 sm:mt-2 text-[10px] sm:text-sm md:text-base leading-tight">RECYCLING</h3>
                                <p class="text-[9px] sm:text-xs md:text-sm text-gray-600 leading-tight">Material Recovery</p>
                            </div>
                           <div class="process-step text-center relative px-1">
                                <div class="icon-box bg-gradient-to-br from-red-50 to-rose-100 p-3 sm:p-4 rounded-full shadow-md mb-2 sm:mb-3 inline-block z-10 border-2 border-rose-300">
                                    <span class="text-2xl sm:text-4xl">🗑️</span>
                                </div>
                                <div class="absolute top-[45px] sm:top-[50px] left-1/2 w-2 h-2 sm:w-3 sm:h-3 bg-rose-500 rounded-full -translate-x-1/2 -translate-y-1/2 z-0"></div>
                                <h3 class="font-semibold text-gray-800 mt-1 sm:mt-2 text-[10px] sm:text-sm md:text-base leading-tight">FINAL DISPOSAL</h3>
                                <p class="text-[9px] sm:text-xs md:text-sm text-gray-600 leading-tight">Landfill / Incineration</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="px-4 mb-16">
             <div class="mx-auto">
                <div class="bg-white p-6 sm:p-8 rounded-xl shadow-lg transform hover:scale-[1.03] transition-all duration-300 hover:shadow-2xl">
                    <div class="text-center mb-8 sm:mb-12">
                        <h2 class="text-2xl sm:text-3xl font-bold mb-3 sm:mb-4 text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600">
                            Latest News & Updates
                        </h2>
                        <p class="text-base sm:text-lg text-gray-600 max-w-2xl mx-auto">
                            Stay informed about developments in waste management and sustainability.
                        </p>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
                        <div class="news-card group bg-gradient-to-br from-green-50 to-emerald-50 p-5 sm:p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col">
                            <div class="mb-4 flex-grow">
                                <span class="text-xs sm:text-sm text-green-600 font-semibold">March 15, 2024</span>
                                <h3 class="text-lg sm:text-xl font-bold text-green-800 mt-1 sm:mt-2">New Recycling Tech</h3>
                                <p class="text-sm sm:text-base text-gray-600 mt-2 leading-relaxed">
                                    Scientists develop method to recycle previously non-recyclable plastics...
                                </p>
                           </div>
                          
                        </div>
                        <div class="news-card group bg-gradient-to-br from-blue-50 to-cyan-50 p-5 sm:p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col">
                            <div class="mb-4 flex-grow">
                                <span class="text-xs sm:text-sm text-blue-600 font-semibold">March 10, 2024</span>
                                <h3 class="text-lg sm:text-xl font-bold text-blue-800 mt-1 sm:mt-2">Global Waste Summit</h3>
                                <p class="text-sm sm:text-base text-gray-600 mt-2 leading-relaxed">
                                    World leaders discuss new policies and initiatives for sustainable waste management...
                                </p>
                            </div>
                           
                        </div>
                        <div class="news-card group bg-gradient-to-br from-purple-50 to-pink-50 p-5 sm:p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col">
                             <div class="mb-4 flex-grow">
                                <span class="text-xs sm:text-sm text-purple-600 font-semibold">March 5, 2024</span>
                                <h3 class="text-lg sm:text-xl font-bold text-purple-800 mt-1 sm:mt-2">Community Program Success</h3>
                                <p class="text-sm sm:text-base text-gray-600 mt-2 leading-relaxed">
                                    Local communities report a 60% increase in recycling rates after new educational programs...
                                </p>
                            </div>
                            
                        </div>
                    </div>
                 </div>
            </div>
        </div>


        <div id="newsPopup" class="fixed inset-0 flex items-center justify-center z-[60] hidden bg-black bg-opacity-70 backdrop-blur-sm transition-opacity duration-300" onclick="hideNewsPopup()">
            <div class="bg-white rounded-xl shadow-2xl p-6 sm:p-8 max-w-2xl w-[90%] mx-auto transform transition-all duration-300 scale-95 opacity-0 relative" id="newsPopupContent" onclick="event.stopPropagation()">
                <button onclick="hideNewsPopup()" class="absolute top-3 right-3 text-gray-500 hover:text-red-600 bg-gray-100 rounded-full p-1.5 leading-none text-2xl z-10" aria-label="Close news popup">
                    ×
                </button>
                <div class="news-popup-content max-h-[80vh] overflow-y-auto pr-2">
                    <div class="mb-4 sm:mb-6">
                        <span class="text-xs sm:text-sm text-gray-500" id="newsDate"></span>
                        <h3 class="text-xl sm:text-2xl font-bold text-gray-800 mt-1 sm:mt-2" id="newsTitle"></h3>
                    </div>
                    <div class="prose prose-sm sm:prose-base max-w-none text-gray-700" id="newsContent">

                    </div>
                </div>
            </div>
        </div>


        <div id="contact-section" class="px-4 mb-16">
            <div class="mx-auto">
                <div class="bg-white p-6 sm:p-8 rounded-xl shadow-lg transform hover:scale-[1.03] transition-all duration-300 hover:shadow-2xl">
                    <div class="text-center mb-8 sm:mb-12">
                        <h2 class="text-2xl sm:text-3xl font-bold mb-3 sm:mb-4 text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600">
                            Let's Talk About Waste Management
                        </h2>
                        <p class="text-base sm:text-lg text-gray-600 max-w-2xl mx-auto">
                            Have questions? Want to share ideas or get involved? We'd love to hear from you!
                        </p>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 items-start">
                        <div class="bg-gradient-to-br from-indigo-50 to-purple-50 p-6 sm:p-8 rounded-xl shadow-inner">
                            <?php if ($contactFormStatus === 'success'): ?>
                                <div class="contact-success-message">
                                    <div class="icon">✅</div>
                                    <h3>Message Sent!</h3>
                                    <p><?php echo htmlspecialchars($contactFormMessage); ?></p>
                                    <a href="index.php#contact-section" class="mt-6 inline-block px-4 py-2 bg-indigo-600 text-white text-sm rounded-lg hover:bg-indigo-700">Send Another</a>
                                </div>
                            <?php else: ?>
                                <?php if ($contactFormStatus === 'error'): ?>
                                    <div class="contact-error-message">
                                        <?php echo htmlspecialchars($contactFormMessage); ?>
                                    </div>
                                <?php endif; ?>
                                <form id="contactForm" method="POST" action="index.php#contact-section" class="space-y-4 sm:space-y-6">
                                    <div>
                                        <label for="name" class="block text-sm font-medium text-gray-700 mb-1.5">Your Name</label>
                                        <input type="text" id="name" name="name" required
                                               class="w-full px-4 py-2.5 rounded-lg border focus:ring-2 focus:border-transparent transition-all duration-300 <?php echo ($contactFormStatus === 'error' && empty($_POST['name'])) ? 'border-red-500 ring-red-500 ring-1' : 'border-gray-300 focus:ring-indigo-500'; ?>"
                                               placeholder="Enter your name"
                                               value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>">
                                    </div>
                                    <div>
                                        <label for="email" class="block text-sm font-medium text-gray-700 mb-1.5">Email Address</label>
                                        <input type="email" id="email" name="email" required
                                               class="w-full px-4 py-2.5 rounded-lg border focus:ring-2 focus:border-transparent transition-all duration-300 <?php echo ($contactFormStatus === 'error' && (empty($_POST['email']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))) ? 'border-red-500 ring-red-500 ring-1' : 'border-gray-300 focus:ring-indigo-500'; ?>"
                                               placeholder="Enter your email"
                                               value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                                    </div>
                                    <div>
                                        <label for="message" class="block text-sm font-medium text-gray-700 mb-1.5">Your Message</label>
                                        <textarea id="message" name="message" rows="4" required
                                                  class="w-full px-4 py-2.5 rounded-lg border focus:ring-2 focus:border-transparent transition-all duration-300 <?php echo ($contactFormStatus === 'error' && empty($_POST['message'])) ? 'border-red-500 ring-red-500 ring-1' : 'border-gray-300 focus:ring-indigo-500'; ?>"
                                                  placeholder="Share your thoughts with us..."><?php echo isset($_POST['message']) ? htmlspecialchars($_POST['message']) : ''; ?></textarea>
                                    </div>
                                    <button type="submit" name="submit_contact" class="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-2.5 sm:py-3 px-6 rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-[1.02] font-semibold">
                                        Send Message
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                        <div class="bg-gradient-to-br from-purple-50 to-pink-50 p-6 sm:p-8 rounded-xl shadow-inner">
                            <div class="space-y-6 sm:space-y-8">
                                <div class="flex items-center space-x-3 sm:space-x-4">
                                    <div class="bg-white p-2.5 sm:p-3 rounded-full shadow-lg flex-shrink-0"> <span class="text-xl sm:text-2xl">📧</span> </div>
                                    <div> <h3 class="text-base sm:text-lg font-semibold text-gray-800">Email Us</h3> <p class="text-sm sm:text-base text-gray-600 break-words">yatinyadav974@gmail.com</p> </div>
                                </div>
                                <div class="flex items-center space-x-3 sm:space-x-4">
                                    <div class="bg-white p-2.5 sm:p-3 rounded-full shadow-lg flex-shrink-0"> <span class="text-xl sm:text-2xl">📱</span> </div>
                                    <div> <h3 class="text-base sm:text-lg font-semibold text-gray-800">Call Us</h3> <p class="text-sm sm:text-base text-gray-600">+91 7974684889</p> </div>
                                </div>
                                <div class="flex items-center space-x-3 sm:space-x-4">
                                    <div class="bg-white p-2.5 sm:p-3 rounded-full shadow-lg flex-shrink-0"> <span class="text-xl sm:text-2xl">📍</span> </div>
                                    <div> <h3 class="text-base sm:text-lg font-semibold text-gray-800">Visit Us</h3> <p class="text-sm sm:text-base text-gray-600">Haryana, India</p> </div>
                                </div>
                                <div class="pt-2 sm:pt-4">
                                    <h3 class="text-base sm:text-lg font-semibold text-gray-800 mb-3 sm:mb-4">Follow Us</h3>
                                    <div class="flex space-x-3 sm:space-x-4">
                                        <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer" class="social-media-link bg-white p-2.5 sm:p-3 rounded-full shadow-lg hover:bg-indigo-100 transition-colors duration-300 transform hover:scale-110" aria-label="Facebook">
                                            <svg class="w-5 h-5 sm:w-6 sm:h-6 text-indigo-600" fill="currentColor" viewBox="0 0 24 24"><path d="M18.77,7.46H14.5v-1.9c0-.9.6-1.1,1-1.1h3V.5h-4.33C10.24.5,9.5,3.44,9.5,5.32v2.15h-3v4h3v12h5v-12h3.85l.42-4Z"/></svg>
                                        </a>
                                        <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" class="social-media-link bg-white p-2.5 sm:p-3 rounded-full shadow-lg hover:bg-pink-100 transition-colors duration-300 transform hover:scale-110" aria-label="Instagram">
                                            <svg class="w-5 h-5 sm:w-6 sm:h-6 text-pink-600" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.14.63c-.789.306-1.459.717-2.126 1.384S.935 3.35.63 4.14C.333 4.905.131 5.775.072 7.053.012 8.333 0 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913.306.788.717 1.459 1.384 2.126.667.666 1.336 1.079 2.126 1.384.766.296 1.636.499 2.913.558C8.333 23.988 8.74 24 12 24s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558.788-.306 1.459-.718 2.126-1.384.666-.667 1.079-1.335 1.384-2.126.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.558-2.913-.306-.789-.718-1.459-1.384-2.126C21.319 1.347 20.651.935 19.86.63c-.765-.297-1.636-.499-2.913-.558C15.667.012 15.26 0 12 0zm0 2.16c3.203 0 3.585.016 4.85.071 1.17.055 1.805.249 2.227.415.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.36 1.057.413 2.227.057 1.266.07 1.646.07 4.85s-.015 3.585-.074 4.85c-.061 1.17-.256 1.805-.421 2.227-.224.562-.479.96-.899 1.382-.419.419-.824.679-1.38.896-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421-.569-.224-.96-.479-1.379-.899-.421-.419-.69-.824-.9-1.38-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678c-3.405 0-6.162 2.76-6.162 6.162 0 3.405 2.76 6.162 6.162 6.162 3.405 0 6.162-2.76 6.162-6.162 0-3.405-2.76-6.162-6.162-6.162zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm7.846-10.405c0 .795-.646 1.44-1.44 1.44-.795 0-1.44-.646-1.44-1.44 0-.794.646-1.439 1.44-1.439.793-.001 1.44.645 1.44 1.439z"/></svg>
                                        </a>
                                        <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" class="social-media-link bg-white p-2.5 sm:p-3 rounded-full shadow-lg hover:bg-red-100 transition-colors duration-300 transform hover:scale-110" aria-label="Youtube">
                                            <svg class="w-5 h-5 sm:w-6 sm:h-6 text-red-600" fill="currentColor" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <style>
            /* Remove AI chat styles */
            .newsletter-msg {
                font-size: 0.875rem;
                margin-top: 0.5rem;
                font-weight: 600;
                transition: opacity 0.3s ease-in-out;
                height: 1.25rem;
                line-height: 1.25rem;
            }
            .newsletter-msg.success { color: #16a34a; }
            .newsletter-msg.error { color: #dc2626; }
            .newsletter-msg.info { color: #2563eb; }
        </style>
    </main>

    <footer class="bg-gradient-to-r from-indigo-800 to-purple-800 text-white py-10 sm:py-12">
        <div class="container mx-auto px-4">
             <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                 <div class="space-y-3">
                    <h3 class="text-lg sm:text-xl font-bold mb-2 sm:mb-4">EcoWaste</h3>
                    <p class="text-indigo-200 text-sm">Making waste management smarter and more sustainable for a cleaner future.</p>
                 </div>
                 <div class="space-y-3">
                    <h3 class="text-lg sm:text-xl font-bold mb-2 sm:mb-4">Quick Links</h3>
                    <ul class="space-y-1.5 text-sm">
                        <li><a href="index.php" class="text-indigo-200 hover:text-white transition-colors duration-300">Home</a></li>
                        <li><a href="learn-segregation.php" class="text-indigo-200 hover:text-white transition-colors duration-300">Learn Segregation</a></li>
                        <li><a href="ai-identifier.php" class="text-indigo-200 hover:text-white transition-colors duration-300">AI Identifier</a></li>
                        <li><a href="disposal-centers.php" class="text-indigo-200 hover:text-white transition-colors duration-300">Find Centers</a></li>
                        <li><a href="contact.php" class="text-indigo-200 hover:text-white transition-colors duration-300">Contact Us</a></li>
                    </ul>
                 </div>
                 <div class="space-y-3">
                    <h3 class="text-lg sm:text-xl font-bold mb-2 sm:mb-4">Contact Us</h3>
                    <ul class="space-y-2 text-sm">
                        <li class="flex items-center text-indigo-200"><svg class="w-4 h-4 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg><span class="break-words">yatinyadav974@gmail.com</span></li>
                        <li class="flex items-center text-indigo-200"><svg class="w-4 h-4 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg><span>+91 7974684889</span></li>
                        <li class="flex items-center text-indigo-200"><svg class="w-4 h-4 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg><span>Haryana, India</span></li>
                    </ul>
                 </div>

                <div class="space-y-4" id="newsletter-section">
                    <h3 class="text-lg sm:text-xl font-bold mb-2 sm:mb-4">Follow Us</h3>
                    <div class="flex space-x-3 sm:space-x-4">
                         <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer" class="social-media-link bg-white p-2.5 sm:p-3 rounded-full shadow-lg hover:bg-indigo-100 transition-colors duration-300 transform hover:scale-110" aria-label="Facebook" onclick="window.open('https://www.facebook.com', '_blank'); return false;"><svg class="w-5 h-5 sm:w-6 sm:h-6 text-indigo-600" fill="currentColor" viewBox="0 0 24 24"><path d="M18.77,7.46H14.5v-1.9c0-.9.6-1.1,1-1.1h3V.5h-4.33C10.24.5,9.5,3.44,9.5,5.32v2.15h-3v4h3v12h5v-12h3.85l.42-4Z"/></svg></a>
                         <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" class="social-media-link bg-white p-2.5 sm:p-3 rounded-full shadow-lg hover:bg-pink-100 transition-colors duration-300 transform hover:scale-110" aria-label="Instagram" onclick="window.open('https://www.instagram.com', '_blank'); return false;"><svg class="w-5 h-5 sm:w-6 sm:h-6 text-pink-600" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.14.63c-.789.306-1.459.717-2.126 1.384S.935 3.35.63 4.14C.333 4.905.131 5.775.072 7.053.012 8.333 0 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913.306.788.717 1.459 1.384 2.126.667.666 1.336 1.079 2.126 1.384.766.296 1.636.499 2.913.558C8.333 23.988 8.74 24 12 24s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558.788-.306 1.459-.718 2.126-1.384.666-.667 1.079-1.335 1.384-2.126.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.558-2.913-.306-.789-.718-1.459-1.384-2.126C21.319 1.347 20.651.935 19.86.63c-.765-.297-1.636-.499-2.913-.558C15.667.012 15.26 0 12 0zm0 2.16c3.203 0 3.585.016 4.85.071 1.17.055 1.805.249 2.227.415.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.36 1.057.413 2.227.057 1.266.07 1.646.07 4.85s-.015 3.585-.074 4.85c-.061 1.17-.256 1.805-.421 2.227-.224.562-.479.96-.899 1.382-.419.419-.824.679-1.38.896-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421-.569-.224-.96-.479-1.379-.899-.421-.419-.69-.824-.9-1.38-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678c-3.405 0-6.162 2.76-6.162 6.162 0 3.405 2.76 6.162 6.162 6.162 3.405 0 6.162-2.76 6.162-6.162 0-3.405-2.76-6.162-6.162-6.162zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm7.846-10.405c0 .795-.646 1.44-1.44 1.44-.795 0-1.44-.646-1.44-1.44 0-.794.646-1.439 1.44-1.439.793-.001 1.44.645 1.44 1.439z"/></svg></a>
                         <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" class="social-media-link bg-white p-2.5 sm:p-3 rounded-full shadow-lg hover:bg-red-100 transition-colors duration-300 transform hover:scale-110" aria-label="Youtube" onclick="window.open('https://www.youtube.com', '_blank'); return false;"><svg class="w-5 h-5 sm:w-6 sm:h-6 text-red-600" fill="currentColor" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg></a>
                    </div>
                    <div class="mt-4 sm:mt-6">
                        <h4 class="text-base sm:text-lg font-semibold mb-2">Subscribe to Our Newsletter</h4>
                        <form id="newsletter-form" action="index.php#newsletter-section" method="POST" class="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
                            <label for="newsletter_email" class="sr-only">Newsletter Email</label>
                            <input type="email" id="newsletter_email" name="newsletter_email" placeholder="Enter your email" required
                                   class="flex-1 px-4 py-2 rounded-lg text-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-indigo-800 focus:ring-indigo-400 text-sm <?php echo ($newsletterStatus === 'error') ? 'border border-red-500 ring-1 ring-red-500' : 'border-gray-300'; ?>"
                                   value="<?php echo ($newsletterStatus === 'error' && isset($_POST['newsletter_email'])) ? htmlspecialchars($_POST['newsletter_email']) : ''; ?>">
                            <button type="submit" name="submit_newsletter" class="bg-indigo-500 hover:bg-indigo-600 px-5 sm:px-6 py-2 rounded-lg transition-colors duration-300 text-white text-sm font-medium">
                                Subscribe
                            </button>
                        </form>
                         <p id="newsletter-message" class="newsletter-msg <?php echo $newsletterStatus; ?>">
                            <?php echo !empty($newsletterMessage) ? htmlspecialchars($newsletterMessage) : ' '; ?>
                         </p>
                    </div>
                </div>
            </div>

            <div class="border-t border-indigo-700 mt-8 pt-6 sm:pt-8 text-center">
                <p class="text-indigo-200 text-xs sm:text-sm">© <?php echo date("Y"); ?> Clear Earth. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        const mobileMenuButton = document.getElementById('mobile-menu-button');
        const mobileMenu = document.getElementById('mobile-menu');
        if(mobileMenuButton && mobileMenu){
            mobileMenuButton.addEventListener('click', () => {
                mobileMenu.classList.toggle('hidden');
            });
        }

        document.addEventListener('DOMContentLoaded', function() {
            const slides = document.querySelectorAll('.slide');
            if (slides.length > 0) {
                let currentSlide = 0;
                const slideCount = slides.length;
                const slideInterval = 5000;

                function showSlide(index) {
                    slides.forEach((slide, i) => {
                        slide.classList.remove('active', 'prev');
                        if (i === index) {
                            slide.classList.add('active');
                        } else if (i === (index - 1 + slideCount) % slideCount) {
                            slide.classList.add('prev');
                        }
                    });
                }

                function nextSlide() {
                    currentSlide = (currentSlide + 1) % slideCount;
                    showSlide(currentSlide);
                }

                showSlide(currentSlide);
                setInterval(nextSlide, slideInterval);
            }

            const typewriterHeadings = document.querySelectorAll('.typewriter');
            typewriterHeadings.forEach(heading => { });
        });

        function toggleDetails(element) {
            const details = element.querySelector('.content-list');
            const allDetails = document.querySelectorAll('.consequences-container .content-list');
            const allSectionBoxes = document.querySelectorAll('.consequences-container .section-box');
            const isActive = element.classList.contains('active');

            allDetails.forEach(detail => {
                if (detail !== details) {
                    detail.classList.remove('show');
                    setTimeout(() => detail.classList.add('hidden'), 50);
                }
            });
             allSectionBoxes.forEach(box => {
                 if (box !== element) box.classList.remove('active');
            });

            if (isActive) {
                details.classList.remove('show');
                element.classList.remove('active');
                setTimeout(() => details.classList.add('hidden'), 50);
            } else {
                details.classList.remove('hidden');
                 void details.offsetWidth;
                details.classList.add('show');
                element.classList.add('active');
            }
        }

        document.addEventListener('click', function(event) {
            const diagramContainer = document.querySelector('.consequences-container');
            if (diagramContainer && !diagramContainer.contains(event.target)) {
                 document.querySelectorAll('.consequences-container .content-list.show').forEach(detail => {
                    detail.classList.remove('show');
                     setTimeout(() => detail.classList.add('hidden'), 50);
                });
                document.querySelectorAll('.consequences-container .section-box.active').forEach(box => {
                    box.classList.remove('active');
                });
            }
        }, true);

        const newsData = {
            1: { date: "March 15, 2024", title: "New Recycling Technology Breakthrough", content: `<p class="mb-4">Scientists at the GreenTech Research Institute have made a groundbreaking discovery in plastic recycling technology. Their new method, called "Molecular Reconstruction," can break down previously non-recyclable plastics into their basic components.</p><p class="mb-4">Key features:</p><ul class="list-disc pl-5 sm:pl-6 mb-4 space-y-1"><li>Can process mixed plastic waste without pre-sorting</li><li>Reduces energy consumption by 60%</li><li>Produces high-quality raw materials</li><li>Expected to reduce landfill waste by 40%</li></ul><p>Pilot plants are underway, with full-scale implementation planned by 2025.</p>` },
            2: { date: "March 10, 2024", title: "Global Waste Management Summit", content: `<p class="mb-4">The 2024 Global Waste Management Summit brought together leaders from 120 countries.</p><p class="mb-4">Key outcomes:</p><ul class="list-disc pl-5 sm:pl-6 mb-4 space-y-1"><li>New international standards for waste reduction</li><li>Commitment to reduce single-use plastics by 50% by 2030</li><li>Global fund for waste management infrastructure</li><li>Launch of the "Zero Waste Cities" initiative</li></ul><p>The summit marks a significant step towards global cooperation on waste issues.</p>` },
            3: { date: "March 5, 2024", title: "Community Recycling Program Success", content: `<p class="mb-4">A local community recycling program reported a remarkable 60% increase in recycling rates in its first year.</p><p class="mb-4">Program highlights:</p><ul class="list-disc pl-5 sm:pl-6 mb-4 space-y-1"><li>Smart recycling bins with real-time monitoring</li><li>Educational workshops and community events</li><li>Reward system for consistent recyclers</li></ul><p>The program's success is inspiring neighboring communities to adopt similar models.</p>`}
        };

        function showNewsPopup(event, newsId) {
            event.preventDefault();
            const popup = document.getElementById('newsPopup');
            const popupContent = document.getElementById('newsPopupContent');
            const news = newsData[newsId];

            if (popup && popupContent && news) {
                document.getElementById('newsDate').textContent = news.date;
                document.getElementById('newsTitle').textContent = news.title;
                document.getElementById('newsContent').innerHTML = news.content;

                popup.classList.remove('hidden');
                document.body.style.overflow = 'hidden';
                requestAnimationFrame(() => {
                     popup.classList.add('opacity-100');
                     popupContent.classList.remove('scale-95', 'opacity-0');
                     popupContent.classList.add('scale-100', 'opacity-100');
                });
            }
        }

        function hideNewsPopup() {
            const popup = document.getElementById('newsPopup');
            const popupContent = document.getElementById('newsPopupContent');

             if (popup && popupContent) {
                popup.classList.remove('opacity-100');
                popupContent.classList.remove('scale-100', 'opacity-100');
                popupContent.classList.add('scale-95', 'opacity-0');
                setTimeout(() => {
                    popup.classList.add('hidden');
                    document.body.style.overflow = '';
                }, 300);
             }
        }

        const newsPopup = document.getElementById('newsPopup');
        if (newsPopup) { newsPopup.addEventListener('click', function(e) { if (e.target === this) { hideNewsPopup(); } }); }
        document.addEventListener('keydown', function(event) { if (event.key === "Escape" && !document.getElementById('newsPopup')?.classList.contains('hidden')) { hideNewsPopup(); } });

        // Add this script at the end of the body tag, before the closing </body>
        document.addEventListener('DOMContentLoaded', function() {
            // Function to open social media links
            function openSocialMedia(url) {
                if (url && typeof url === 'string') {
                    try {
                        const newWindow = window.open(url, '_blank', 'noopener,noreferrer');
                        if (newWindow) {
                            newWindow.focus();
                        } else {
                            // Fallback if popup is blocked
                            window.location.href = url;
                        }
                    } catch (error) {
                        console.error('Error opening social media link:', error);
                        // Fallback to direct navigation
                        window.location.href = url;
                    }
                }
            }

            // Add click handlers to all social media links
            document.querySelectorAll('.social-media-link, a[href*="facebook.com"], a[href*="instagram.com"], a[href*="youtube.com"]').forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    const url = this.getAttribute('href');
                    if (url) {
                        openSocialMedia(url);
                    }
                });
            });
        });

        // Social Media Links
        document.querySelectorAll('.social-media-link').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const url = this.getAttribute('href');
                if (url) {
                    window.open(url, '_blank', 'noopener,noreferrer');
                }
            });
        });
    </script>
</body>
</html>