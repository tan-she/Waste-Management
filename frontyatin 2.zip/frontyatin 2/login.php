<?php
$conn = new mysqli("localhost", "root", "", "clearearth");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $email = mysqli_real_escape_string($conn, $email);
    $query = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($query);
    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            session_start();
            $_SESSION['email'] = $user['email'];
            $_SESSION['name'] = $user['name']; 
            echo '<script>
                alert("Login successful! Redirecting to home page...");
                window.location.href = "index.php";
            </script>';
            exit;
        } else {
            echo "❌ Incorrect password.";
        }
    } else {
        echo "❌ No account found with this email.";
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - EcoWaste</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="styles.css">
    <style>
        .logo-container {
            width: 48px;
            height: 48px;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .logo-circle {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: linear-gradient(135deg, #2563EB 0%, #F97316 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .logo-circle:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        .recycle-arrows {
            width: 24px;
            height: 24px;
            animation: spin 20s linear infinite;
        }
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body class="bg-gradient-to-b from-indigo-50 to-purple-50 min-h-screen">
    <!-- Navigation Bar -->
    <nav class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-4 fixed w-full top-0 z-50 shadow-lg">
        <div class="container mx-auto flex justify-between items-center">
            <div class="flex items-center">
                <a href="index.php" class="transform hover:scale-105 transition-transform duration-300">
                    <div class="logo-container">
                        <div class="logo-circle">
                            <svg class="recycle-arrows" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M21 10C21 7.17157 19.9464 4.45867 18.0711 2.58337C16.1957 0.708074 13.4828 -0.345703 10.6544 -0.345703" 
                                    stroke="white" stroke-width="2" stroke-linecap="round"
                                    transform="rotate(0 12 12)">
                                    <animateTransform
                                        attributeName="transform"
                                        type="rotate"
                                        from="0 12 12"
                                        to="120 12 12"
                                        dur="3s"
                                        repeatCount="indefinite"/>
                                </path>
                                <path d="M10.6544 -0.345703L13.6544 2.65429L7.6544 2.65429L10.6544 -0.345703Z" 
                                    fill="white"
                                    transform="rotate(0 12 12)">
                                    <animateTransform
                                        attributeName="transform"
                                        type="rotate"
                                        from="0 12 12"
                                        to="120 12 12"
                                        dur="3s"
                                        repeatCount="indefinite"/>
                                </path>
                                <path d="M21 10C21 7.17157 19.9464 4.45867 18.0711 2.58337C16.1957 0.708074 13.4828 -0.345703 10.6544 -0.345703" 
                                    stroke="white" stroke-width="2" stroke-linecap="round"
                                    transform="rotate(120 12 12)">
                                    <animateTransform
                                        attributeName="transform"
                                        type="rotate"
                                        from="120 12 12"
                                        to="240 12 12"
                                        dur="3s"
                                        repeatCount="indefinite"/>
                                </path>
                                <path d="M10.6544 -0.345703L13.6544 2.65429L7.6544 2.65429L10.6544 -0.345703Z" 
                                    fill="white"
                                    transform="rotate(120 12 12)">
                                    <animateTransform
                                        attributeName="transform"
                                        type="rotate"
                                        from="120 12 12"
                                        to="240 12 12"
                                        dur="3s"
                                        repeatCount="indefinite"/>
                                </path>
                                <path d="M21 10C21 7.17157 19.9464 4.45867 18.0711 2.58337C16.1957 0.708074 13.4828 -0.345703 10.6544 -0.345703" 
                                    stroke="white" stroke-width="2" stroke-linecap="round"
                                    transform="rotate(240 12 12)">
                                    <animateTransform
                                        attributeName="transform"
                                        type="rotate"
                                        from="240 12 12"
                                        to="360 12 12"
                                        dur="3s"
                                        repeatCount="indefinite"/>
                                </path>
                                <path d="M10.6544 -0.345703L13.6544 2.65429L7.6544 2.65429L10.6544 -0.345703Z" 
                                    fill="white"
                                    transform="rotate(240 12 12)">
                                    <animateTransform
                                        attributeName="transform"
                                        type="rotate"
                                        from="240 12 12"
                                        to="360 12 12"
                                        dur="3s"
                                        repeatCount="indefinite"/>
                                </path>
                            </svg>
                        </div>
                    </div>
                </a>
            </div>

            <div class="flex space-x-4">
                <a href="signup.php" class="text-white hover:text-indigo-200 transition-colors duration-300 font-medium">Sign Up</a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="container mx-auto px-4 pt-24 pb-12">
        <div class="max-w-md mx-auto">
            <div class="bg-white rounded-xl shadow-lg p-8">
                <div class="text-center mb-8">
                    <h1 class="text-3xl font-bold text-indigo-700 mb-2">Sign In</h1>
                    <p class="text-gray-600">Welcome back! Please login to continue.</p>
                </div>

                <form class="space-y-6" action="login.php" method="POST">
                    <div>
                        <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                        <input type="email" id="email" name="email" required class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent" placeholder="Enter your email">
                    </div>

                    <div>
                        <label for="password" class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                        <input type="password" id="password" name="password" required 
                               class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent" 
                               placeholder="Enter your password"
                               pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                               title="Must contain at least one number, one uppercase and lowercase letter, and at least 8 or more characters">
                        <div id="password-requirements" class="mt-1 text-sm text-gray-500">
                            Password must contain:
                            <ul class="list-disc pl-2">
                                <li id="uppercase">At least one uppercase letter</li>
                                <li id="lowercase">At least one lowercase letter</li>
                                <li id="number">At least one number</li>
                                <li id="length">At least 8 characters</li>
                            </ul>
                        </div>
                    </div>

                    <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-4 rounded-lg transition-colors duration-300">
                        Log In
                    </button>
                </form>

                <div class="mt-6 text-center">
                    <p class="text-sm text-gray-600">
                        Don't have an account yet?
                        <a href="signup.php" class="text-indigo-600 hover:text-indigo-500 font-medium">Sign up</a>
                    </p>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer Section -->
    <footer class="bg-gradient-to-r from-indigo-800 to-purple-800 text-white py-12">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <!-- Company Info -->
                <div class="space-y-4">
                    <h3 class="text-xl font-bold mb-4">EcoWaste</h3>
                    <p class="text-indigo-200">Making waste management smarter and more sustainable for a cleaner future.</p>
                </div>

                <!-- Quick Links -->
                <div class="space-y-4">
                    <h3 class="text-xl font-bold mb-4">Quick Links</h3>
                    <ul class="space-y-2">
                        <li><a href="index.html" class="text-indigo-200 hover:text-white transition-colors duration-300">Home</a></li>
                        <li><a href="learn-segregation.html" class="text-indigo-200 hover:text-white transition-colors duration-300">Learn Segregation</a></li>
                        <li><a href="ai-identifier.html" class="text-indigo-200 hover:text-white transition-colors duration-300">AI Identifier</a></li>
                        <li><a href="disposal-centers.html" class="text-indigo-200 hover:text-white transition-colors duration-300">Find Centers</a></li>
                    </ul>
                </div>

                <!-- Contact Info -->
                <div class="space-y-4">
                    <h3 class="text-xl font-bold mb-4">Contact Us</h3>
                    <ul class="space-y-2">
                        <li class="flex items-center text-indigo-200">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                            </svg> yatinyadav974@gmail.com
                        </li>
                        <li class="flex items-center text-indigo-200">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2H5a2 2 0 01-2-2V5z" />
                            </svg> +91 7974684889
                            
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <script>
        document.getElementById('password').addEventListener('input', function(e) {
            const password = e.target.value;
            const uppercase = /[A-Z]/.test(password);
            const lowercase = /[a-z]/.test(password);
            const number = /[0-9]/.test(password);
            const length = password.length >= 8;

            document.getElementById('uppercase').style.color = uppercase ? 'green' : 'red';
            document.getElementById('lowercase').style.color = lowercase ? 'green' : 'red';
            document.getElementById('number').style.color = number ? 'green' : 'red';
            document.getElementById('length').style.color = length ? 'green' : 'red';
        });
    </script>

    <!-- Success Popup -->
    <div id="successPopup" class="fixed inset-0 z-50 hidden">
        <!-- Dark overlay -->
        <div class="absolute inset-0 bg-gray-900 opacity-50"></div>
        <!-- Popup content -->
        <div class="relative min-h-screen flex items-center justify-center p-4">
            <div id="popupContent" class="bg-white rounded-2xl p-8 max-w-md w-full transform transition-all duration-300 scale-95 opacity-0 shadow-2xl">
                <div class="text-center">
                    <!-- Animated checkmark -->
                    <div class="mx-auto flex items-center justify-center h-24 w-24 rounded-full bg-green-100 mb-6">
                        <svg class="h-16 w-16 text-green-600 animate-bounce" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"></path>
                        </svg>
                    </div>
                    <!-- Text content -->
                    <h2 class="text-3xl font-bold text-gray-900 mb-4">Login Successful!</h2>
                    <p class="text-lg text-gray-600 mb-8">Welcome back!</p>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Function to manually show popup for testing
        function showPopup() {
            const popup = document.getElementById('successPopup');
            const popupContent = document.getElementById('popupContent');
            
            // Show popup
            popup.classList.remove('hidden');
            document.body.style.overflow = 'hidden';
            
            // Animate popup
            setTimeout(() => {
                popupContent.classList.remove('scale-95', 'opacity-0');
                popupContent.classList.add('scale-100', 'opacity-100');
            }, 10);
        }

        // Check if login was successful (this will be set by PHP)
        <?php if(isset($_GET['success']) && $_GET['success'] == 1): ?>
        // Show popup immediately when page loads
        window.onload = function() {
            showPopup();
            
            // Redirect after delay
            setTimeout(() => {
                window.location.href = 'index.php';
            }, 3000);
        };
        <?php endif; ?>
    </script>
</body>
</html>
