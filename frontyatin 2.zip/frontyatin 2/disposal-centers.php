<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Find Disposal Centers - EcoWaste</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        // Define the initialization function before loading the API
        function initMap() {
            const map = new google.maps.Map(document.getElementById('map'), {
                center: { lat: 40.7128, lng: -74.0060 },
                zoom: 13,
                mapTypeControl: true,
                streetViewControl: true,
                fullscreenControl: true,
                zoomControl: true
            });

            const disposalCenters = [
                { name: 'Green Valley Recycling', lat: 40.7128, lng: -74.0060 },
                { name: 'Eco-Friendly Waste', lat: 40.7142, lng: -74.0064 },
                { name: 'Sustainable Solutions', lat: 40.7135, lng: -74.0068 }
            ];

            disposalCenters.forEach(center => {
                const marker = new google.maps.Marker({
                    position: { lat: center.lat, lng: center.lng },
                    map: map,
                    title: center.name,
                    icon: {
                        url: 'https://maps.google.com/mapfiles/ms/icons/green-dot.png'
                    }
                });

                const infoWindow = new google.maps.InfoWindow({
                    content: `<div class="p-2">
                        <h3 class="font-bold">${center.name}</h3>
                        <p class="text-sm">Click for more details</p>
                    </div>`
                });

                marker.addListener('click', () => {
                    infoWindow.open(map, marker);
                });
            });
        }

        // Handle API loading errors
        function handleMapError() {
            document.getElementById('map').innerHTML = `
                <div class="flex items-center justify-center h-full bg-gray-100 rounded-lg">
                    <div class="text-center p-4">
                        <p class="text-red-600 font-semibold">Failed to load Google Maps</p>
                        <p class="text-gray-600 text-sm mt-2">Please check your internet connection and try again</p>
                    </div>
                </div>
            `;
        }
    </script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB41DRUbKWJHPxaFjMAwdrzWzbVKartNGg&callback=initMap"></script>
    <link rel="stylesheet" href="styles.css">
    <style>
        #map {
            height: 400px;
            width: 100%;
            border-radius: 0.5rem;
        }
        .map-container {
            position: relative;
            height: 400px;
            width: 100%;
            margin: 20px 0;
            border: 1px solid #e2e8f0;
            border-radius: 0.5rem;
            overflow: hidden;
        }
        .search-box {
            position: absolute;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1;
            background: white;
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.3);
            width: 300px;
        }
        .search-box input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .map-controls {
            position: absolute;
            right: 10px;
            top: 10px;
            z-index: 1;
        }
        .map-controls button {
            background: white;
            border: none;
            border-radius: 4px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.3);
            margin: 5px;
            padding: 8px;
            cursor: pointer;
        }
        .google-style-map {
            background: #f8f9fa;
            position: relative;
            min-height: 500px;
            border: 1px solid #dadce0;
            border-radius: 0.5rem;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .map-terrain {
            position: absolute;
            width: 100%;
            height: 100%;
            background: 
                linear-gradient(45deg, #e8eaed 25%, transparent 25%),
                linear-gradient(-45deg, #e8eaed 25%, transparent 25%),
                linear-gradient(45deg, transparent 75%, #e8eaed 75%),
                linear-gradient(-45deg, transparent 75%, #e8eaed 75%);
            background-size: 20px 20px;
            background-position: 0 0, 0 10px, 10px -10px, -10px 0px;
            opacity: 0.7;
        }

        .road {
            position: absolute;
            background: #ffffff;
            box-shadow: 0 0 4px rgba(0,0,0,0.1);
        }

        .road.highway {
            background: #f8f9fa;
            border: 2px solid #dadce0;
            width: 100%;
        }

        .road.highway.horizontal {
            height: 20px;
            top: 30%;
        }

        .road.highway.vertical {
            width: 20px;
            height: 100%;
            left: 40%;
        }

        .road.street {
            background: #f1f3f4;
            border: 1px solid #dadce0;
        }

        .road.street.horizontal {
            height: 10px;
            width: 100%;
            top: 60%;
        }

        .road.street.vertical {
            width: 10px;
            height: 100%;
            left: 70%;
        }

        .building {
            width: 30px;
            height: 40px;
            background: #f1f3f4;
            border: 1px solid #dadce0;
            position: absolute;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .marker-pin {
            width: 24px;
            height: 24px;
            background: #ea4335;
            border: 2px solid #ffffff;
            border-radius: 50%;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
            position: absolute;
            transform: translate(-50%, -50%);
            cursor: pointer;
            transition: transform 0.2s;
            z-index: 10;
        }

        .marker-pin::after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 0;
            border-left: 8px solid transparent;
            border-right: 8px solid transparent;
            border-top: 8px solid #ea4335;
        }

        .marker-pin:hover {
            transform: translate(-50%, -50%) scale(1.2);
        }

        .map-controls {
            position: absolute;
            right: 20px;
            top: 20px;
            z-index: 20;
        }

        .control-btn {
            width: 40px;
            height: 40px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: #5f6368;
            cursor: pointer;
            margin-bottom: 10px;
            transition: background-color 0.2s;
        }

        .control-btn:hover {
            background-color: #f8f9fa;
        }

        .search-box {
            position: absolute;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            z-index: 20;
            width: 300px;
            padding: 10px;
        }

        .search-box input {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #dadce0;
            border-radius: 4px;
            font-size: 14px;
            outline: none;
            transition: border-color 0.2s;
        }

        .search-box input:focus {
            border-color: #4285f4;
        }

        .map-overlay {
            position: absolute;
            bottom: 20px;
            left: 20px;
            background: white;
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            z-index: 20;
            font-size: 12px;
            color: #5f6368;
        }

        .info-window {
            position: absolute;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            padding: 15px;
            width: 200px;
            z-index: 30;
            display: none;
        }

        .info-window h3 {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 5px;
            color: #202124;
        }

        .info-window p {
            font-size: 14px;
            color: #5f6368;
            margin-bottom: 10px;
        }

        .info-window button {
            background: #4285f4;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 5px 10px;
            font-size: 12px;
            cursor: pointer;
        }

        .info-window .close-btn {
            position: absolute;
            top: 5px;
            right: 5px;
            background: none;
            border: none;
            font-size: 16px;
            color: #5f6368;
            cursor: pointer;
        }

        /* Add modal styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
        }

        .modal-content {
            position: relative;
            background-color: white;
            margin: 10% auto;
            padding: 20px;
            width: 90%;
            max-width: 600px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .modal-close {
            position: absolute;
            right: 20px;
            top: 20px;
            font-size: 24px;
            cursor: pointer;
            color: #6B7280;
        }

        .modal-close:hover {
            color: #374151;
        }

        .facility-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body class="bg-gradient-to-b from-indigo-50 to-purple-50">
    <!-- Navigation Bar -->
    <nav class="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white p-4 fixed w-full top-0 z-50 shadow-lg">
        <div class="container mx-auto flex justify-between items-center">
            <div class="flex items-center">
                <a href="index.html" class="transform hover:scale-105 transition-transform duration-300">
                    <div class="logo-container">
                        <div class="logo-circle">
                            <svg class="recycle-arrows" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <!-- First Arrow -->
                                <path d="M21 10C21 7.17157 19.9464 4.45867 18.0711 2.58337C16.1957 0.708074 13.4828 -0.345703 10.6544 -0.345703" 
                                    stroke="white" stroke-width="2" stroke-linecap="round"
                                    transform="rotate(0 12 12)">
                                    <animateTransform
                                        attributeName="transform"
                                        type="rotate"
                                        from="0 12 12"
                                        to="120 12 12"
                                        dur="3s"
                                        repeatCount="indefinite"/>
                                </path>
                                <!-- Arrow Head 1 -->
                                <path d="M10.6544 -0.345703L13.6544 2.65429L7.6544 2.65429L10.6544 -0.345703Z" 
                                    fill="white"
                                    transform="rotate(0 12 12)">
                                    <animateTransform
                                        attributeName="transform"
                                        type="rotate"
                                        from="0 12 12"
                                        to="120 12 12"
                                        dur="3s"
                                        repeatCount="indefinite"/>
                                </path>
                                <!-- Second Arrow -->
                                <path d="M21 10C21 7.17157 19.9464 4.45867 18.0711 2.58337C16.1957 0.708074 13.4828 -0.345703 10.6544 -0.345703" 
                                    stroke="white" stroke-width="2" stroke-linecap="round"
                                    transform="rotate(120 12 12)">
                                    <animateTransform
                                        attributeName="transform"
                                        type="rotate"
                                        from="120 12 12"
                                        to="240 12 12"
                                        dur="3s"
                                        repeatCount="indefinite"/>
                                </path>
                                <!-- Arrow Head 2 -->
                                <path d="M10.6544 -0.345703L13.6544 2.65429L7.6544 2.65429L10.6544 -0.345703Z" 
                                    fill="white"
                                    transform="rotate(120 12 12)">
                                    <animateTransform
                                        attributeName="transform"
                                        type="rotate"
                                        from="120 12 12"
                                        to="240 12 12"
                                        dur="3s"
                                        repeatCount="indefinite"/>
                                </path>
                                <!-- Third Arrow -->
                                <path d="M21 10C21 7.17157 19.9464 4.45867 18.0711 2.58337C16.1957 0.708074 13.4828 -0.345703 10.6544 -0.345703" 
                                    stroke="white" stroke-width="2" stroke-linecap="round"
                                    transform="rotate(240 12 12)">
                                    <animateTransform
                                        attributeName="transform"
                                        type="rotate"
                                        from="240 12 12"
                                        to="360 12 12"
                                        dur="3s"
                                        repeatCount="indefinite"/>
                                </path>
                                <!-- Arrow Head 3 -->
                                <path d="M10.6544 -0.345703L13.6544 2.65429L7.6544 2.65429L10.6544 -0.345703Z" 
                                    fill="white"
                                    transform="rotate(240 12 12)">
                                    <animateTransform
                                        attributeName="transform"
                                        type="rotate"
                                        from="240 12 12"
                                        to="360 12 12"
                                        dur="3s"
                                        repeatCount="indefinite"/>
                                </path>
                            </svg>
                        </div>
                    </div>
                </a>
                <div class="hidden md:flex space-x-8 ml-8">
                    <a href="index.php" class="hover:text-indigo-200 transition-colors duration-300 font-medium">Home</a>
                    <a href="learn-segregation.php" class="hover:text-indigo-200 transition-colors duration-300 font-medium">Learn Segregation</a>
                    <a href="ai-identifier.php" class="hover:text-indigo-200 transition-colors duration-300 font-medium">AI Identifier</a>
                    <a href="disposal-centers.php" class="hover:text-indigo-200 transition-colors duration-300 font-medium">Find Disposal Centers</a>
                    <a href="contact.php" class="hover:text-indigo-200 transition-colors duration-300 font-medium">Contact Us</a>
                </div>
            </div>
            
            <div class="flex items-center">
                <div class="flex items-center relative group">
                    <div class="relative">
                        <input type="text" 
                               id="searchInput"
                               placeholder="Search centers, guides..." 
                               class="px-4 py-2 rounded-lg text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm w-48 transition-all duration-300 bg-white/90 backdrop-blur-sm"
                               onfocus="showSearchDropdown()"
                               onblur="hideSearchDropdown()">
                        <button class="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-indigo-600 transition-colors duration-300">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                            </svg>
                        </button>
                        <!-- Search Dropdown -->
                        <div id="searchDropdown" class="absolute top-full left-0 w-full mt-1 bg-white rounded-lg shadow-xl border border-gray-200 hidden z-50">
                            <div class="p-2">
                                <div class="text-xs text-gray-500 font-medium mb-2 px-2">Recent Searches</div>
                                <div class="space-y-1">
                                    <a href="#" class="block px-2 py-1.5 text-sm text-gray-700 hover:bg-indigo-50 rounded-md transition-colors duration-200">
                                        <div class="flex items-center">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                            </svg>
                                            Recycling Center Near Me
                                        </div>
                                    </a>
                                    <a href="#" class="block px-2 py-1.5 text-sm text-gray-700 hover:bg-indigo-50 rounded-md transition-colors duration-200">
                                        <div class="flex items-center">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                            </svg>
                                            How to Recycle Electronics
                                        </div>
                                    </a>
                                </div>
                                <div class="border-t border-gray-100 my-2"></div>
                                <div class="text-xs text-gray-500 font-medium mb-2 px-2">Quick Links</div>
                                <div class="space-y-1">
                                    <a href="disposal-centers.html" class="block px-2 py-1.5 text-sm text-gray-700 hover:bg-indigo-50 rounded-md transition-colors duration-200">
                                        <div class="flex items-center">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                                            </svg>
                                            Find Disposal Centers
                                        </div>
                                    </a>
                                    <a href="learn-segregation.html" class="block px-2 py-1.5 text-sm text-gray-700 hover:bg-indigo-50 rounded-md transition-colors duration-200">
                                        <div class="flex items-center">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                                            </svg>
                                            Learn Waste Segregation
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="container mx-auto px-4 pt-24">
        <div class="max-w-6xl mx-auto">
            <h1 class="text-5xl font-bold text-indigo-700 mb-8 text-center animate-fade-in">Find Disposal Centers</h1>
            <p class="text-xl text-gray-600 mb-12 text-center max-w-3xl mx-auto">Locate the nearest waste disposal and recycling centers in your area.</p>
            
            <!-- Google Map Section -->
            <section class="py-12 bg-gray-50">
                <div class="container mx-auto px-4">
                    <div class="map-container bg-white rounded-lg shadow-lg p-4">
                        <div class="google-style-map">
                            <div class="map-container">
                                <iframe 
                                    width="100%" 
                                    height="100%" 
                                    frameborder="0" 
                                    scrolling="no" 
                                    marginheight="0" 
                                    marginwidth="0" 
                                    src="https://www.openstreetmap.org/export/embed.html?bbox=-74.0060%2C40.7128%2C-74.0060%2C40.7128&layer=mapnik&marker=40.7128%2C-74.0060">
                                </iframe>
                                <br/>
                                <small>
                                    <a href="https://www.openstreetmap.org/?mlat=40.7128&mlon=-74.0060#map=13/40.7128/-74.0060" target="_blank">
                                        View Larger Map
                                    </a>
                                </small>
                            </div>
                            
                            <!-- Markers -->
                            <div class="marker-pin" style="top: 25%; left: 25%;" title="Green Valley Recycling" data-id="1"></div>
                            <div class="marker-pin" style="top: 55%; left: 35%;" title="Eco-Friendly Waste" data-id="2"></div>
                            <div class="marker-pin" style="top: 75%; left: 65%;" title="Sustainable Solutions" data-id="3"></div>
                            
                            <!-- Map Controls -->
                            <div class="map-controls">
                                <div class="control-btn" onclick="zoomIn()">+</div>
                                <div class="control-btn" onclick="zoomOut()">-</div>
                            </div>

                            <!-- Map Overlay -->
                            <div class="map-overlay">
                                © 2024 EcoWaste Map
                            </div>

                            <!-- Info Windows -->
                            <div class="info-window" id="info-window-1" style="top: 15%; left: 30%;">
                                <span class="close-btn" onclick="closeInfoWindow('info-window-1')">×</span>
                                <h3>Green Valley Recycling</h3>
                                <p>123 Eco Street, Green City</p>
                                <p>Open: 8:00 AM - 6:00 PM</p>
                                <button onclick="alert('Directions to Green Valley Recycling')">Get Directions</button>
                            </div>

                            <div class="info-window" id="info-window-2" style="top: 45%; left: 40%;">
                                <span class="close-btn" onclick="closeInfoWindow('info-window-2')">×</span>
                                <h3>Eco-Friendly Waste</h3>
                                <p>456 Green Avenue, Eco City</p>
                                <p>Open: 7:00 AM - 7:00 PM</p>
                                <button onclick="alert('Directions to Eco-Friendly Waste')">Get Directions</button>
                            </div>

                            <div class="info-window" id="info-window-3" style="top: 65%; left: 70%;">
                                <span class="close-btn" onclick="closeInfoWindow('info-window-3')">×</span>
                                <h3>Sustainable Solutions</h3>
                                <p>789 Environment Road, Green Valley</p>
                                <p>Open: 9:00 AM - 5:00 PM</p>
                                <button onclick="alert('Directions to Sustainable Solutions')">Get Directions</button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            <!-- Results Section -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- Center Card 1 -->
                <div class="bg-white p-6 rounded-xl shadow-lg transform hover:scale-105 transition-transform duration-300 hover:shadow-xl border-t-4 border-purple-500">
                    <div class="flex items-start">
                        <div class="bg-purple-100 p-3 rounded-full">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                            </svg>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-xl font-semibold text-purple-600">Green Valley Recycling Center</h3>
                            <p class="text-gray-600 mt-1">123 Eco Street, Green City</p>
                            <div class="mt-4 space-y-2">
                                <div class="flex items-center text-sm text-gray-500">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                    Open 8:00 AM - 6:00 PM
                                </div>
                                <div class="flex items-center text-sm text-gray-500">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                    </svg>
                                    2.5 miles away
                                </div>
                            </div>
                            <div class="mt-4">
                                <button onclick="openModal('modal-1')" class="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors duration-300 text-sm">
                                    View Details
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Center Card 2 -->
                <div class="bg-white p-6 rounded-xl shadow-lg transform hover:scale-105 transition-transform duration-300 hover:shadow-xl border-t-4 border-indigo-500">
                    <div class="flex items-start">
                        <div class="bg-indigo-100 p-3 rounded-full">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                            </svg>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-xl font-semibold text-indigo-600">Eco-Friendly Waste Management</h3>
                            <p class="text-gray-600 mt-1">456 Green Avenue, Eco City</p>
                            <div class="mt-4 space-y-2">
                                <div class="flex items-center text-sm text-gray-500">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                    Open 7:00 AM - 7:00 PM
                                </div>
                                <div class="flex items-center text-sm text-gray-500">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                    </svg>
                                    3.1 miles away
                                </div>
                            </div>
                            <div class="mt-4">
                                <button onclick="openModal('modal-2')" class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors duration-300 text-sm">
                                    View Details
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Center Card 3 -->
                <div class="bg-white p-6 rounded-xl shadow-lg transform hover:scale-105 transition-transform duration-300 hover:shadow-xl border-t-4 border-purple-500">
                    <div class="flex items-start">
                        <div class="bg-purple-100 p-3 rounded-full">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                            </svg>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-xl font-semibold text-purple-600">Sustainable Waste Solutions</h3>
                            <p class="text-gray-600 mt-1">789 Environment Road, Green Valley</p>
                            <div class="mt-4 space-y-2">
                                <div class="flex items-center text-sm text-gray-500">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                    Open 9:00 AM - 5:00 PM
                                </div>
                                <div class="flex items-center text-sm text-gray-500">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                    </svg>
                                    4.2 miles away
                                </div>
                            </div>
                            <div class="mt-4">
                                <button onclick="openModal('modal-3')" class="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors duration-300 text-sm">
                                    View Details
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <style>
        .logo-container {
            width: 50px;
            height: 50px;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .logo-circle {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: linear-gradient(135deg, #10B981 0%, #3B82F6 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            position: relative;
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        .logo-circle:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 8px rgba(0, 0, 0, 0.2);
        }
        .recycle-arrows {
            width: 70%;
            height: 70%;
            position: relative;
            animation: spin 20s linear infinite;
        }
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
    </style>

    <script>
        function zoomIn() {
            const map = document.querySelector('.google-style-map');
            const currentScale = parseFloat(map.style.transform.replace('scale(', '').replace(')', '')) || 1;
            map.style.transform = `scale(${currentScale + 0.1})`;
        }

        function zoomOut() {
            const map = document.querySelector('.google-style-map');
            const currentScale = parseFloat(map.style.transform.replace('scale(', '').replace(')', '')) || 1;
            if (currentScale > 0.5) {
                map.style.transform = `scale(${currentScale - 0.1})`;
            }
        }

        // Add click event to markers
        document.querySelectorAll('.marker-pin').forEach(marker => {
            marker.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const infoWindow = document.getElementById(`info-window-${id}`);
                
                // Close all info windows first
                document.querySelectorAll('.info-window').forEach(window => {
                    window.style.display = 'none';
                });
                
                // Show the clicked marker's info window
                infoWindow.style.display = 'block';
            });
        });

        function closeInfoWindow(id) {
            document.getElementById(id).style.display = 'none';
        }

        // Close info windows when clicking outside
        document.addEventListener('click', function(event) {
            if (!event.target.closest('.marker-pin') && !event.target.closest('.info-window')) {
                document.querySelectorAll('.info-window').forEach(window => {
                    window.style.display = 'none';
                });
            }
        });

        // Add modal functionality
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
            document.body.style.overflow = 'hidden'; // Prevent scrolling when modal is open
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
            document.body.style.overflow = 'auto'; // Restore scrolling
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        }

        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                document.querySelectorAll('.modal').forEach(modal => {
                    modal.style.display = 'none';
                });
                document.body.style.overflow = 'auto';
            }
        });
    </script>

    <!-- Add modals for each center -->
    <div id="modal-1" class="modal">
        <div class="modal-content">
            <span class="modal-close" onclick="closeModal('modal-1')">&times;</span>
            <img src="https://images.unsplash.com/photo-1532996122724-e3c354a0b15b" alt="Green Valley Recycling" class="facility-image">
            <h2 class="text-2xl font-bold text-indigo-600 mb-4">Green Valley Recycling Center</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h3 class="font-semibold text-gray-700 mb-2">Contact Information</h3>
                    <p class="text-gray-600">📍 123 Eco Street, Green City</p>
                    <p class="text-gray-600">📞 (555) 123-4567</p>
                    <p class="text-gray-600">✉️ info@greenvalley.com</p>
                </div>
                <div>
                    <h3 class="font-semibold text-gray-700 mb-2">Operating Hours</h3>
                    <p class="text-gray-600">Monday - Friday: 8:00 AM - 6:00 PM</p>
                    <p class="text-gray-600">Saturday: 9:00 AM - 4:00 PM</p>
                    <p class="text-gray-600">Sunday: Closed</p>
                </div>
            </div>
            <div class="mt-6">
                <h3 class="font-semibold text-gray-700 mb-2">Accepted Materials</h3>
                <ul class="grid grid-cols-2 gap-2 text-gray-600">
                    <li>✓ Paper & Cardboard</li>
                    <li>✓ Glass & Plastic</li>
                    <li>✓ Metal & Electronics</li>
                    <li>✓ Batteries</li>
                    <li>✓ Garden Waste</li>
                    <li>✓ Construction Debris</li>
                </ul>
            </div>
            <div class="mt-6">
                <h3 class="font-semibold text-gray-700 mb-2">Additional Services</h3>
                <p class="text-gray-600">• Free recycling consultation</p>
                <p class="text-gray-600">• Electronic waste disposal certification</p>
                <p class="text-gray-600">• Bulk item pickup service</p>
            </div>
        </div>
    </div>

    <div id="modal-2" class="modal">
        <div class="modal-content">
            <span class="modal-close" onclick="closeModal('modal-2')">&times;</span>
            <img src="https://images.unsplash.com/photo-1595278069441-2cf29f8005a4" alt="Eco-Friendly Waste" class="facility-image">
            <h2 class="text-2xl font-bold text-indigo-600 mb-4">Eco-Friendly Waste Management</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h3 class="font-semibold text-gray-700 mb-2">Contact Information</h3>
                    <p class="text-gray-600">📍 456 Green Avenue, Eco City</p>
                    <p class="text-gray-600">📞 (555) 234-5678</p>
                    <p class="text-gray-600">✉️ contact@ecofriendly.com</p>
                </div>
                <div>
                    <h3 class="font-semibold text-gray-700 mb-2">Operating Hours</h3>
                    <p class="text-gray-600">Monday - Friday: 7:00 AM - 7:00 PM</p>
                    <p class="text-gray-600">Saturday: 8:00 AM - 5:00 PM</p>
                    <p class="text-gray-600">Sunday: 10:00 AM - 3:00 PM</p>
                </div>
            </div>
            <div class="mt-6">
                <h3 class="font-semibold text-gray-700 mb-2">Accepted Materials</h3>
                <ul class="grid grid-cols-2 gap-2 text-gray-600">
                    <li>✓ Household Waste</li>
                    <li>✓ Recyclables</li>
                    <li>✓ Hazardous Waste</li>
                    <li>✓ Industrial Waste</li>
                    <li>✓ Green Waste</li>
                    <li>✓ E-Waste</li>
                </ul>
            </div>
            <div class="mt-6">
                <h3 class="font-semibold text-gray-700 mb-2">Special Programs</h3>
                <p class="text-gray-600">• Community recycling education</p>
                <p class="text-gray-600">• Corporate waste management solutions</p>
                <p class="text-gray-600">• Monthly e-waste collection events</p>
            </div>
        </div>
    </div>

    <div id="modal-3" class="modal">
        <div class="modal-content">
            <span class="modal-close" onclick="closeModal('modal-3')">&times;</span>
            <img src="https://images.unsplash.com/photo-1591193686104-fddba4d0e4d8" alt="Sustainable Solutions" class="facility-image">
            <h2 class="text-2xl font-bold text-indigo-600 mb-4">Sustainable Waste Solutions</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h3 class="font-semibold text-gray-700 mb-2">Contact Information</h3>
                    <p class="text-gray-600">📍 789 Environment Road, Green Valley</p>
                    <p class="text-gray-600">📞 (555) 345-6789</p>
                    <p class="text-gray-600">✉️ info@sustainablesolutions.com</p>
                </div>
                <div>
                    <h3 class="font-semibold text-gray-700 mb-2">Operating Hours</h3>
                    <p class="text-gray-600">Monday - Friday: 9:00 AM - 5:00 PM</p>
                    <p class="text-gray-600">Saturday: 10:00 AM - 4:00 PM</p>
                    <p class="text-gray-600">Sunday: Closed</p>
                </div>
            </div>
            <div class="mt-6">
                <h3 class="font-semibold text-gray-700 mb-2">Accepted Materials</h3>
                <ul class="grid grid-cols-2 gap-2 text-gray-600">
                    <li>✓ Plastics (All Types)</li>
                    <li>✓ Paper Products</li>
                    <li>✓ Metal & Aluminum</li>
                    <li>✓ Glass</li>
                    <li>✓ Organic Waste</li>
                    <li>✓ Textiles</li>
                </ul>
            </div>
            <div class="mt-6">
                <h3 class="font-semibold text-gray-700 mb-2">Sustainability Initiatives</h3>
                <p class="text-gray-600">• Zero-waste consulting</p>
                <p class="text-gray-600">• Composting workshops</p>
                <p class="text-gray-600">• Recycling reward program</p>
            </div>
        </div>
    </div>
</body>
</html> 