<?php
ini_set('display_errors', 1); // Show errors for debugging (remove in production)
error_reporting(E_ALL);    // Report all errors

// --- Configuration ---
$uploadDir = 'uploads/'; // Directory to save images (relative to this script)
$maxFileSize = 5 * 1024 * 1024; // 5 MB limit

// --- PHP Logic ---
$show_results = false;
$error_message = '';
$saved_image_path = ''; // Path to the actually saved image for display
$result_waste_type = 'N/A';
$result_disposal_method = 'N/A';
$result_recyclability = 'N/A';
$result_recycling_center = 'N/A';

// Predefined waste data
$wasteData = [
    'Plastic Bottle' => ['disposal_method' => 'Recycle Bin (Clean & Empty)', 'recyclability' => 'Highly Recyclable (Check cap rules)', 'recycling_center' => 'Green Earth Recycling Center'],
    'Newspaper' => ['disposal_method' => 'Recycle Bin (Keep Dry)', 'recyclability' => 'Highly Recyclable', 'recycling_center' => 'Eco-Friendly Waste Management'],
    'Glass Jar' => ['disposal_method' => 'Recycle Bin (Clean, Lid separate)', 'recyclability' => 'Highly Recyclable', 'recycling_center' => 'Sustainable Solutions Hub'],
    'Aluminum Can' => ['disposal_method' => 'Recycle Bin (Empty)', 'recyclability' => 'Highly Recyclable', 'recycling_center' => 'Community Recycling Point'],
    'Banana Peel' => ['disposal_method' => 'Compost Bin / Organic Waste', 'recyclability' => 'Compostable', 'recycling_center' => 'Local Composting Facility'],
    'Old Smartphone' => ['disposal_method' => 'E-Waste Drop-off', 'recyclability' => 'Special E-Waste Recycling', 'recycling_center' => 'E-Waste Collection Center'],
    'Used Battery' => ['disposal_method' => 'Hazardous Waste Drop-off', 'recyclability' => 'Requires Special Handling', 'recycling_center' => 'Hazardous Waste Management Center'],
    'Cardboard Box' => ['disposal_method' => 'Recycle Bin (Flattened)', 'recyclability' => 'Highly Recyclable', 'recycling_center' => 'Clean Earth Recycling'],
    'Styrofoam' => ['disposal_method' => 'General Waste (Check local options)', 'recyclability' => 'Limited / Specialized', 'recycling_center' => 'Check council website']
];

// --- Handle Form Submission ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 1. Check if file input exists and was uploaded successfully
    if (isset($_FILES['wasteImage']) && $_FILES['wasteImage']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['wasteImage'];

        // 2. Validate File Size
        if ($file['size'] > $maxFileSize) {
            $error_message = "File is too large. Maximum size is " . ($maxFileSize / 1024 / 1024) . " MB.";
        } else {
            // 3. Validate File Type (basic check using extension)
            $fileName = basename($file['name']);
            $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];

            if (!in_array($fileExtension, $allowedExtensions)) {
                $error_message = "Invalid file type. Only JPG, JPEG, PNG, GIF are allowed.";
            } else {
                // 4. Create Upload Directory if it doesn't exist
                if (!is_dir($uploadDir)) {
                    if (!mkdir($uploadDir, 0775, true)) { // Create recursively, set permissions
                        $error_message = "Error: Could not create the upload directory. Please check server permissions.";
                    }
                }

                // Check again if directory exists and is writable (in case mkdir failed silently or permissions changed)
                if (is_dir($uploadDir) && is_writable($uploadDir)) {

                    // 5. Generate a Unique Filename
                    $newFileName = uniqid('img_', true) . '.' . $fileExtension;
                    $destination = $uploadDir . $newFileName;

                    // 6. Move the uploaded file
                    if (move_uploaded_file($file['tmp_name'], $destination)) {
                        // --- File Saved Successfully ---
                        $saved_image_path = $destination; // Use this path for the <img> src

                        // --- Simulate AI Identification (Pick Random Data) ---
                        $wasteKeys = array_keys($wasteData);
                        $randomKey = $wasteKeys[array_rand($wasteKeys)];
                        $selectedWasteInfo = $wasteData[$randomKey];

                        // Assign results
                        $result_waste_type = $randomKey;
                        $result_disposal_method = $selectedWasteInfo['disposal_method'];
                        $result_recyclability = $selectedWasteInfo['recyclability'];
                        $result_recycling_center = $selectedWasteInfo['recycling_center'];

                        $show_results = true; // Flag to display results section in HTML

                    } else {
                        $error_message = "Error: Could not save the uploaded file. Check directory permissions.";
                    }
                } else {
                     if (empty($error_message)) { // Avoid overwriting mkdir error
                         $error_message = "Error: Upload directory does not exist or is not writable.";
                     }
                }
            }
        }
    } else {
        // Handle upload errors
        switch ($_FILES['wasteImage']['error'] ?? UPLOAD_ERR_NO_FILE) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                $error_message = "The uploaded file exceeds the maximum allowed size.";
                break;
            case UPLOAD_ERR_PARTIAL:
                $error_message = "The file was only partially uploaded. Please try again.";
                break;
            case UPLOAD_ERR_NO_FILE:
                $error_message = "No file was selected for upload.";
                break;
            default:
                $error_message = "An unexpected error occurred during file upload. Code: " . ($_FILES['wasteImage']['error'] ?? 'Unknown');
                break;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Waste Identifier - EcoWaste</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="styles.css"> <!-- Make sure you have this file or remove link -->
    <style>
        /* Basic styles from previous example - Add more as needed */
        .logo-container { 
            width: 48px; 
            height: 48px; 
            position: relative; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
        }
        .logo-circle { 
            width: 100%; 
            height: 100%; 
            border-radius: 50%; 
            background: linear-gradient(135deg, #2563EB 0%, #F97316 100%); 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06); 
            transition: transform 0.3s ease, box-shadow 0.3s ease; 
        }
        .logo-circle:hover { 
            transform: scale(1.05); 
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05); 
        }
        .recycle-arrows { 
            width: 24px; 
            height: 24px; 
            animation: spin 20s linear infinite; 
        }
        @keyframes spin { 
            from { transform: rotate(0deg); } 
            to { transform: rotate(360deg); } 
        }
        .error-message-box { background-color: #fef2f2; color: #dc2626; border: 1px solid #fecaca; border-left-width: 4px; border-left-color: #dc2626; padding: 1rem; border-radius: 0.5rem; margin-bottom: 1.5rem; }
        #resultsSection, #uploadedImageContainer { animation: fadeIn 0.5s ease-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .preview-container { position: relative; max-width: 350px; margin: 1rem auto; background-color: #f9fafb; padding: 0.5rem; border-radius: 0.5rem; box-shadow: inset 0 2px 4px rgba(0,0,0,0.06); }
        .preview-image { max-width: 100%; height: auto; max-height: 250px; border-radius: 0.375rem; display: block; margin: 0 auto; }
        .spinner { border: 4px solid rgba(0, 0, 0, 0.1); width: 36px; height: 36px; border-radius: 50%; border-left-color: #4f46e5; animation: spin 1s ease infinite; margin: 1rem auto; display: none; /* Initially hidden */ }
         @keyframes spin { to { transform: rotate(360deg); } }
    </style>
</head>
<body class="bg-gradient-to-b from-indigo-50 to-purple-50 min-h-screen flex flex-col">
    <!-- Navigation Bar -->
    <nav class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-4 fixed w-full top-0 z-50 shadow-lg">
        <div class="container mx-auto flex justify-between items-center">
            <div class="flex items-center">
                <a href="index.php" class="transform hover:scale-105 transition-transform duration-300">
                    <div class="logo-container">
                        <div class="logo-circle">
                            <svg class="recycle-arrows" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M21 10C21 7.17157 19.9464 4.45867 18.0711 2.58337C16.1957 0.708074 13.4828 -0.345703 10.6544 -0.345703" 
                                    stroke="white" stroke-width="2" stroke-linecap="round"
                                    transform="rotate(0 12 12)">
                                    <animateTransform
                                        attributeName="transform"
                                        type="rotate"
                                        from="0 12 12"
                                        to="120 12 12"
                                        dur="3s"
                                        repeatCount="indefinite"/>
                                </path>
                                <path d="M10.6544 -0.345703L13.6544 2.65429L7.6544 2.65429L10.6544 -0.345703Z" 
                                    fill="white"
                                    transform="rotate(0 12 12)">
                                    <animateTransform
                                        attributeName="transform"
                                        type="rotate"
                                        from="0 12 12"
                                        to="120 12 12"
                                        dur="3s"
                                        repeatCount="indefinite"/>
                                </path>
                                <path d="M21 10C21 7.17157 19.9464 4.45867 18.0711 2.58337C16.1957 0.708074 13.4828 -0.345703 10.6544 -0.345703" 
                                    stroke="white" stroke-width="2" stroke-linecap="round"
                                    transform="rotate(120 12 12)">
                                    <animateTransform
                                        attributeName="transform"
                                        type="rotate"
                                        from="120 12 12"
                                        to="240 12 12"
                                        dur="3s"
                                        repeatCount="indefinite"/>
                                </path>
                                <path d="M10.6544 -0.345703L13.6544 2.65429L7.6544 2.65429L10.6544 -0.345703Z" 
                                    fill="white"
                                    transform="rotate(120 12 12)">
                                    <animateTransform
                                        attributeName="transform"
                                        type="rotate"
                                        from="120 12 12"
                                        to="240 12 12"
                                        dur="3s"
                                        repeatCount="indefinite"/>
                                </path>
                                <path d="M21 10C21 7.17157 19.9464 4.45867 18.0711 2.58337C16.1957 0.708074 13.4828 -0.345703 10.6544 -0.345703" 
                                    stroke="white" stroke-width="2" stroke-linecap="round"
                                    transform="rotate(240 12 12)">
                                    <animateTransform
                                        attributeName="transform"
                                        type="rotate"
                                        from="240 12 12"
                                        to="360 12 12"
                                        dur="3s"
                                        repeatCount="indefinite"/>
                                </path>
                                <path d="M10.6544 -0.345703L13.6544 2.65429L7.6544 2.65429L10.6544 -0.345703Z" 
                                    fill="white"
                                    transform="rotate(240 12 12)">
                                    <animateTransform
                                        attributeName="transform"
                                        type="rotate"
                                        from="240 12 12"
                                        to="360 12 12"
                                        dur="3s"
                                        repeatCount="indefinite"/>
                                </path>
                            </svg>
                        </div>
                    </div>
                </a>
            </div>
            <div class="hidden md:flex space-x-8">
                 <a href="index.php" class="hover:text-indigo-200 transition-colors duration-300 font-medium">Home</a>
                 <a href="learn-segregation.php" class="hover:text-indigo-200 transition-colors duration-300 font-medium">Learn Segregation</a>
                 <a href="ai-identifier.php" class="text-indigo-200 font-semibold transition-colors duration-300">AI Identifier</a>
                 <a href="disposal-centers.php" class="hover:text-indigo-200 transition-colors duration-300 font-medium">Find Disposal Center</a>
                 <a href="contact.php" class="hover:text-indigo-200 transition-colors duration-300 font-medium">Contact Us</a>
            </div>
            <div class="flex items-center relative group"> <!-- Search --> <div class="relative"> <input type="text" id="searchInput" placeholder="Search..." class="px-4 py-2 rounded-lg text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm w-48 bg-white/90 backdrop-blur-sm" onfocus="showSearchDropdown()" oninput="showSearchDropdown()" onblur="hideSearchDropdown()"> <button class="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-indigo-600"> <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg> </button> <div id="searchDropdown" class="absolute top-full left-0 w-full max-h-60 overflow-y-auto mt-1 bg-white rounded-lg shadow-xl border border-gray-200 hidden z-50"></div> </div> </div>
         </div>
    </nav>

    <!-- Main Content -->
    <main class="container mx-auto px-4 pt-24 flex-grow">
        <div class="max-w-3xl mx-auto">
            <h1 class="text-4xl md:text-5xl font-bold text-indigo-700 mb-6 text-center animate-fade-in">AI Waste Identifier 📷</h1>
            <p class="text-lg md:text-xl text-gray-600 mb-10 text-center">Upload a photo of your waste item. We'll save it and give you (random) disposal advice!</p>

             <?php if (!empty($error_message)): ?>
                <div class="error-message-box">
                    <p class="font-semibold">Upload Failed!</p>
                    <p><?php echo htmlspecialchars($error_message); ?></p>
                </div>
            <?php endif; ?>

            <!-- Form Section -->
            <form id="aiIdentifierForm" action="ai-identifier.php" method="POST" enctype="multipart/form-data" class="bg-white rounded-xl shadow-lg p-6 md:p-8">
                <div class="text-center mb-6">
                    <h2 class="text-2xl md:text-3xl font-semibold text-indigo-700 mb-3">Upload Image</h2>
                    <p class="text-gray-500">Select a clear picture of the waste item.</p>
                </div>

                <!-- Upload Area -->
                <div class="border-2 border-dashed border-indigo-300 rounded-lg p-6 md:p-8 text-center mb-6 bg-indigo-50 hover:bg-indigo-100 transition-colors duration-200">
                    <input type="file" name="wasteImage" id="wasteImage" accept="image/jpeg, image/png, image/gif" class="hidden" required>
                    <label for="wasteImage" class="cursor-pointer group">
                        <div class="flex flex-col items-center">
                            <svg class="w-12 h-12 text-indigo-500 group-hover:text-indigo-600 mb-3 transition-colors duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                            <span id="uploadLabelText" class="text-indigo-600 font-medium group-hover:underline">Click to upload image</span>
                            <span class="text-gray-500 text-sm mt-1">JPG, PNG, GIF - Max 5MB</span>
                        </div>
                    </label>
                </div>

                 <!-- Client-side Image Preview -->
                 <div id="clientPreviewContainer" class="mb-6 text-center hidden">
                      <p class="text-sm text-gray-600 mb-2 italic">Image selected (preview):</p>
                      <div class="preview-container">
                          <img id="clientPreviewImage" class="preview-image" alt="Client-side preview" src="#">
                      </div>
                 </div>


                 <!-- Loading Spinner (controlled by JS) -->
                 <div id="loadingSpinner" class="spinner"></div>

                 <!-- Results Section (Shown after successful PHP processing) -->
                 <?php if ($show_results): ?>
                 <div id="resultsSection">
                     <hr class="my-6 border-indigo-200">
                     <h3 class="text-xl md:text-2xl font-semibold text-indigo-800 mb-4 text-center">Identification Results</h3>

                     <!-- Display Saved Image -->
                     <div id="uploadedImageContainer" class="mb-6 text-center">
                          <p class="text-sm text-gray-600 mb-2 italic">Uploaded Image:</p>
                          <div class="preview-container border border-gray-300">
                              <img id="savedImagePreview" class="preview-image" alt="Saved waste image"
                                   src="<?php echo htmlspecialchars($saved_image_path); ?>?t=<?php echo time(); // Cache buster ?>">
                          </div>
                     </div>

                     <!-- Display Dummy Data -->
                    <div class="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg p-5 md:p-6 border border-indigo-200 shadow-inner">
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6">
                            <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                                <h4 class="text-sm font-medium text-gray-500 mb-1 uppercase tracking-wider">Identified As</h4>
                                <p class="text-indigo-700 text-lg font-semibold"><?php echo htmlspecialchars($result_waste_type); ?></p>
                            </div>
                            <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                                <h4 class="text-sm font-medium text-gray-500 mb-1 uppercase tracking-wider">Disposal Advice</h4>
                                <p class="text-indigo-700 text-lg font-semibold"><?php echo htmlspecialchars($result_disposal_method); ?></p>
                            </div>
                            <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                                <h4 class="text-sm font-medium text-gray-500 mb-1 uppercase tracking-wider">Recyclability</h4>
                                <p class="text-indigo-700 text-lg font-semibold"><?php echo htmlspecialchars($result_recyclability); ?></p>
                            </div>
                            <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                                <h4 class="text-sm font-medium text-gray-500 mb-1 uppercase tracking-wider">Facility Suggestion</h4>
                                <p class="text-indigo-700 text-lg font-semibold"><?php echo htmlspecialchars($result_recycling_center); ?></p>
                            </div>
                        </div>
                    </div>
                 </div>
                 <?php endif; ?>


                <!-- Submit Button -->
                <div class="text-center mt-8">
                    <button type="submit" id="identifyButton" class="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-semibold py-3 px-10 rounded-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 shadow-md hover:shadow-lg" disabled>
                        Identify Waste
                    </button>
                </div>
            </form>
        </div>
    </main>

    <!-- Footer Section -->
    <footer class="bg-gradient-to-r from-indigo-800 to-purple-800 text-white py-12 mt-16">
       <div class="container mx-auto px-4">
           <!-- Footer Content (as before) -->
           <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8"> <div class="space-y-3"><h3 class="text-xl font-bold">EcoWaste</h3><p class="text-indigo-200 text-sm">Making waste management smarter...</p></div> <div class="space-y-3"><h3 class="text-lg font-semibold">Quick Links</h3><ul class="space-y-1 text-sm"><li><a href="index.php" class="text-indigo-200 hover:text-white">Home</a></li><li><a href="learn-segregation.php" class="text-indigo-200 hover:text-white">Learn Segregation</a></li><li><a href="ai-identifier.php" class="text-indigo-200 hover:text-white">AI Identifier</a></li><li><a href="disposal-centers.php" class="text-indigo-200 hover:text-white">Find Centers</a></li><li><a href="contact.php" class="text-indigo-200 hover:text-white">Contact Us</a></li></ul></div> <div class="space-y-3"><h3 class="text-lg font-semibold">Contact Info</h3><ul class="space-y-1 text-sm"><li class="flex items-center text-indigo-200"><svg class="w-4 h-4 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>yatinyadav974@gmail.com.com</li><li class="flex items-center text-indigo-200"><svg class="w-4 h-4 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>+91 7974684889</li></ul></div> <div class="space-y-3"><h3 class="text-lg font-semibold">Follow Us</h3><div class="flex space-x-3"> 
    <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer" class="transform hover:scale-110 transition-transform duration-300">
        <div class="bg-indigo-700 p-2 rounded-full hover:bg-indigo-600 transition-colors duration-300">
            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M18.77,7.46H14.5v-1.9c0-.9.6-1.1,1-1.1h3V.5h-4.33C10.24.5,9.5,3.44,9.5,5.32v2.15h-3v4h3v12h5v-12h3.85l.42-4Z"/>
            </svg>
        </div>
    </a>
    <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" class="transform hover:scale-110 transition-transform duration-300">
        <div class="bg-indigo-700 p-2 rounded-full hover:bg-indigo-600 transition-colors duration-300">
            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
            </svg>
        </div>
    </a>
    <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" class="transform hover:scale-110 transition-transform duration-300">
        <div class="bg-indigo-700 p-2 rounded-full hover:bg-indigo-600 transition-colors duration-300">
            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.14.63c-.789.306-1.459.717-2.126 1.384S.935 3.35.63 4.14C.333 4.905.131 5.775.072 7.053.012 8.333 0 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913.306.788.717 1.459 1.384 2.126.667.666 1.336 1.079 2.126 1.384.766.296 1.636.499 2.913.558C8.333 23.988 8.74 24 12 24s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558.788-.306 1.459-.718 2.126-1.384.666-.667 1.079-1.335 1.384-2.126.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.421-2.913-.224.562-.479.96-.899 1.382-.419.419-.824.679-1.38.896-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421-.569-.224-.96-.479-1.379-.899-.421-.419-.69-.824-.9-1.38-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678c-3.405 0-6.162 2.76-6.162 6.162 0 3.405 2.76 6.162 6.162 6.162 3.405 0 6.162-2.76 6.162-6.162 0-3.405-2.76-6.162-6.162-6.162zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm7.846-10.405c0 .795-.646 1.44-1.44 1.44-.795 0-1.44-.646-1.44-1.44 0-.794.646-1.439 1.44-1.439.793-.001 1.44.645 1.44 1.439z"/>
            </svg>
        </div>
    </a>
</div></div> </div>
           <!-- Copyright -->
           <div class="border-t border-indigo-700 mt-8 pt-8 text-center">
               <p class="text-indigo-200 text-sm">© <?php echo date("Y"); ?> EcoWaste. All rights reserved.</p>
           </div>
       </div>
    </footer>

    <script>
        // --- Client-Side JavaScript Enhancements ---

        const wasteImageInput = document.getElementById('wasteImage');
        const clientPreviewContainer = document.getElementById('clientPreviewContainer');
        const clientPreviewImage = document.getElementById('clientPreviewImage');
        const uploadLabelText = document.getElementById('uploadLabelText');
        const identifyButton = document.getElementById('identifyButton');
        const loadingSpinner = document.getElementById('loadingSpinner');
        const aiIdentifierForm = document.getElementById('aiIdentifierForm');
        const resultsSection = document.getElementById('resultsSection');

        const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB in bytes

        // Handle file selection and client-side preview
        wasteImageInput.addEventListener('change', function(e) {
            const file = e.target.files[0];

            // Reset state
            clientPreviewContainer.classList.add('hidden');
            identifyButton.disabled = true;
            uploadLabelText.textContent = 'Click to upload image'; // Reset label
             if (resultsSection) {
                  resultsSection.style.display = 'none'; // Hide old results on new selection
             }


            if (file) {
                // Validate file size
                if (file.size > MAX_FILE_SIZE) {
                     alert(`File is too large (${(file.size / 1024 / 1024).toFixed(1)}MB). Maximum size is 5MB.`);
                     wasteImageInput.value = ''; // Clear the invalid file selection
                     return;
                }

                // Validate file type (client-side check for immediate feedback)
                 const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
                 if (!allowedTypes.includes(file.type)) {
                     alert('Invalid file type. Please select a JPG, PNG, or GIF image.');
                     wasteImageInput.value = ''; // Clear the invalid file selection
                     return;
                 }


                // Show client-side preview
                const reader = new FileReader();
                reader.onload = function(e) {
                    clientPreviewImage.src = e.target.result;
                    clientPreviewContainer.classList.remove('hidden');
                    identifyButton.disabled = false; // Enable button
                    uploadLabelText.textContent = `Selected: ${file.name}`; // Update label
                }
                reader.readAsDataURL(file);
            }
        });

        // Show spinner on form submission
        aiIdentifierForm.addEventListener('submit', function(e) {
            // Check if a file is actually selected (avoids spinner on empty submit attempt if 'required' fails)
            if (wasteImageInput.files.length === 0) {
                alert("Please select an image file first.");
                e.preventDefault(); // Prevent submission if no file
                return;
            }
             if (identifyButton.disabled) { // Prevent double submit
                e.preventDefault();
                return;
             }

            identifyButton.disabled = true; // Disable button
            loadingSpinner.style.display = 'block'; // Show spinner
            identifyButton.innerHTML = 'Identifying...'; // Change button text

            // Optional: Add a small delay to simulate processing if needed for UX
            // setTimeout(() => {}, 500); // Allow spinner to be visible

            // Form submission will proceed naturally after this
        });

        // --- Search Bar JS (Keep as is or adapt) ---
         const centersData = [ // Example data - replace with your actual data source if needed
            { name: 'Green Earth Recycling Center', location: 'Mumbai, Maharashtra', distance: '2.5 miles' },
            { name: 'Eco-Friendly Waste Management', location: 'Delhi, NCR', distance: '3.1 miles' },
            { name: 'Sustainable Solutions Hub', location: 'Bangalore, Karnataka', distance: '4.2 miles' },
             // Add more centers...
         ];

         function showSearchDropdown() {
            const searchInput = document.getElementById('searchInput');
            const searchDropdown = document.getElementById('searchDropdown');
            if (!searchInput || !searchDropdown) return; // Defensive check

            const searchTerm = searchInput.value.toLowerCase().trim();
            searchDropdown.innerHTML = ''; // Clear previous results

            if (searchTerm.length > 1) {
                 const filteredCenters = centersData.filter(center =>
                    center.name.toLowerCase().includes(searchTerm) ||
                    center.location.toLowerCase().includes(searchTerm)
                );

                 if (filteredCenters.length > 0) {
                    filteredCenters.forEach(center => {
                        const div = document.createElement('div');
                        div.className = 'p-2 hover:bg-indigo-100 cursor-pointer text-sm border-b border-gray-100 last:border-b-0';
                        div.innerHTML = `<div class="font-medium text-gray-800">${center.name}</div><div class="text-xs text-gray-500">${center.location}</div><div class="text-xs text-green-600">${center.distance} away</div>`;
                        div.addEventListener('mousedown', () => {
                            searchInput.value = center.name;
                            searchDropdown.classList.add('hidden');
                            console.log(`Selected: ${center.name}`);
                        });
                        searchDropdown.appendChild(div);
                    });
                 } else {
                    const div = document.createElement('div');
                    div.className = 'p-2 text-sm text-gray-500';
                    div.textContent = 'No centers found.';
                    searchDropdown.appendChild(div);
                 }
                 searchDropdown.classList.remove('hidden');
            } else {
                searchDropdown.classList.add('hidden');
            }
        }

        function hideSearchDropdown() {
             setTimeout(() => {
                const searchDropdown = document.getElementById('searchDropdown');
                if (searchDropdown) searchDropdown.classList.add('hidden');
            }, 200);
        }

         // Add event listeners for search
        document.getElementById('searchInput')?.addEventListener('focus', showSearchDropdown);
        document.getElementById('searchInput')?.addEventListener('input', showSearchDropdown);
        document.getElementById('searchInput')?.addEventListener('blur', hideSearchDropdown);

    </script>
</body>
</html>