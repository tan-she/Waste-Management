<?php
$host = "localhost";
$dbname = "clearearth";
$username = "root";
$password = ""; // Agar tu password use kar raha hai toh yahan password daal

try {
    // PDO object create karte hain
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    
    // Error handling mode set karte hain
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Connection success message (optional)
    // echo "Connected successfully"; 
} catch(PDOException $e) {
    // Agar connection mein koi error hota hai toh
    die("Connection failed: " . $e->getMessage());
}
?>
